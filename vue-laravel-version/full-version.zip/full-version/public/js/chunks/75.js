(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[75],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Search.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/Search.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_video_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-video-player */ "./node_modules/vue-video-player/dist/vue-video-player.js");
/* harmony import */ var vue_video_player__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_video_player__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var video_js_dist_video_js_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! video.js/dist/video-js.css */ "./node_modules/video.js/dist/video-js.css");
/* harmony import */ var video_js_dist_video_js_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(video_js_dist_video_js_css__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      searchQuery: 'Modern Admin',
      currentPage: 1,
      knowledgePanel: {
        img: __webpack_require__(/*! @assets/images/pages/modern.jpg */ "./resources/assets/images/pages/modern.jpg"),
        title: 'Modern Admin - Clean Bootstrap 4 Dashboard HTML Template',
        subtitle: 'Clean Bootstrap 4 Dashboard HTML Template',
        description: 'Clean Bootstrap 4 Dashboard HTML Template + Bitcoin Dashboard can be used for any type of web applications: Project Management, eCommerce backends, CRM, Analytics, Fitness or any custom admin panels.',
        info: [{
          title: '1,367',
          subtitle: 'Sales'
        }, {
          title: '74',
          subtitle: 'Comments'
        }, {
          title: '5',
          subtitle: 'Ratings'
        }],
        externalLink: {
          title: 'View on Themeforest',
          icon: 'ExternalLinkIcon',
          url: 'https://1.envato.market/modern_admin'
        },
        resultMetaList: [{
          name: 'Bootstrap',
          value: 'v4.13 updated'
        }, {
          name: 'Created',
          value: 'Mar 8 2018'
        }, {
          name: 'Last Update',
          value: 'Nov 28 2018'
        }, {
          name: 'Documentation',
          value: 'Well Documented'
        }, {
          name: 'Layout',
          value: 'Responsive'
        }],
        suggestedSearches: [{
          name: 'Apex',
          img: __webpack_require__(/*! @assets/images/pages/1-apex.png */ "./resources/assets/images/pages/1-apex.png"),
          url: 'https://1.envato.market/apex_admin'
        }, {
          name: 'Convex',
          img: __webpack_require__(/*! @assets/images/pages/3-convex.png */ "./resources/assets/images/pages/3-convex.png"),
          url: 'https://1.envato.market/convex_angular_admin'
        }, {
          name: 'Materialize',
          img: __webpack_require__(/*! @assets/images/pages/4-materialize.png */ "./resources/assets/images/pages/4-materialize.png"),
          url: 'https://1.envato.market/materialize_admin'
        }, {
          name: 'Stack',
          img: __webpack_require__(/*! @assets/images/pages/2-stack.png */ "./resources/assets/images/pages/2-stack.png"),
          url: 'https://1.envato.market/stack_admin'
        }]
      },
      searchResults: [{
        title: 'Modern Admin - Clean Bootstrap 4 Dashboard HTML Template',
        linkUrl: 'https://1.envato.market/modern_admin',
        resultUrl: 'https://1.envato.market/pixinvent_portfolio',
        metaData: {
          ratings: 5,
          info: ['25 reviews', '25.00 USD', 'In Stock']
        },
        time: 'Mon Dec 10 2018 07:45:00 GMT+0000 (GMT)',
        description: 'Cake sesame snaps cupcake gingerbread danish I love gingerbread. Apple pie pie jujubes chupa chups muffin halvah lollipop. Chocolate cake oat cake tiramisu marzipan sugar plum. Donut sweet pie oat cake dragée fruitcake cotton candy lemon drops. Sweet roll wafer bear claw tiramisu oat cake.',
        sitelinks: [{
          title: 'Dashboard',
          url: 'https://1.envato.market/modern_admin',
          description: 'Halvah marzipan icing chocolate caramels candy canes carrot cake dragée apple pie. Croissant oat cake gummies biscuit.'
        }, {
          title: 'UI Components',
          url: 'https://1.envato.market/modern_admin',
          description: 'Brownie lollipop chocolate bar chocolate cake macaroon. Bonbon chocolate tootsie roll chocolate.'
        }, {
          title: 'Form Elements',
          url: 'https://1.envato.market/modern_admin',
          description: 'Lollipop cake wafer. Candy chocolate toffee icing. Chocolate cake cupcake toffee chupa chups topping.'
        }, {
          title: 'Support',
          url: 'https://1.envato.market/modern_admin',
          description: 'Carrot cake sweet soufflé cake bear claw lollipop. Muffin sugar plum chupa chups liquorice cotton candy halvah danish cake.'
        }, {
          title: 'Charts',
          url: 'https://1.envato.market/modern_admin',
          description: 'Gingerbread chupa chups toffee jelly chocolate cake tiramisu marshmallow. Donut tiramisu chocolate marshmallow.'
        }, {
          title: 'Documentation',
          url: 'https://1.envato.market/modern_admin',
          description: 'Powder brownie candy toffee soufflé. Gingerbread sweet roll gingerbread icing macaroon.'
        }]
      }, {
        title: 'Attire bench - Quick win shoot me an email',
        linkUrl: 'https://1.envato.market/modern_admin',
        resultUrl: 'https://1.envato.market/pixinvent_portfolio',
        resultImg: __webpack_require__(/*! @assets/images/pages/search-result.jpg */ "./resources/assets/images/pages/search-result.jpg"),
        metaData: {
          ratings: 4.5,
          info: ['17 reviews', '12 votes', '28.00 USD', 'In Stock']
        },
        time: 'Mon Feb 23 2017 07:45:00 GMT+0000 (GMT)',
        description: 'Tiramisu soufflé gummies ice cream liquorice gingerbread sweet roll. Cake cotton candy candy ice cream muffin donut soufflé danish. Dessert jelly beans wafer cheesecake. Sugar plum gingerbread caramels candy canes gummi bears bear claw donut. Oat cake cookie tiramisu sweet halvah sugar plum. Dessert danish oat cake.'
      }, {
        title: 'The Table - for what do you feel you would',
        linkUrl: 'https://1.envato.market/modern_admin',
        resultUrl: 'https://1.envato.market/pixinvent_portfolio',
        resultVideo: [{
          sources: [{
            type: 'video/mp4',
            src: 'http://vjs.zencdn.net/v/oceans.mp4'
          }],
          poster: 'https://surmon-china.github.io/vue-quill-editor/static/images/surmon-1.jpg'
        }],
        metaData: {
          info: ['1M Views', 'Uploaded by PlayStation']
        },
        time: 'Mon Jun 25 2016 07:45:00 GMT+0000 (GMT)',
        description: 'Tiramisu soufflé gummies ice cream liquorice gingerbread sweet roll. Cake cotton candy candy ice cream muffin donut soufflé danish. Dessert jelly beans wafer cheesecake. Sugar plum gingerbread caramels candy canes gummi bears bear claw donut. Oat cake cookie tiramisu sweet halvah sugar plum. Dessert danish oat cake.'
      }, {
        title: 'Microdosing - deep v actually schlitz chia',
        linkUrl: 'https://1.envato.market/modern_admin',
        resultUrl: 'https://1.envato.market/pixinvent_portfolio',
        description: 'Wafer liquorice sweet roll jelly beans cake soufflé. Oat cake marzipan chocolate cake sesame snaps jujubes. Dragée biscuit dessert. Chocolate muffin wafer. Sugar plum icing tootsie roll gummi bears marzipan candy canes biscuit.'
      }, {
        title: 'Aesthetic neutra freegan, mlkshk literally',
        linkUrl: 'https://1.envato.market/modern_admin',
        resultUrl: 'https://1.envato.market/pixinvent_portfolio',
        time: 'Mon Jun 30 2017 10:30:00 GMT+0000 (GMT)',
        description: 'Donut jelly cake chupa chups powder chocolate cake cheesecake. Wafer macaroon sweet roll gingerbread cheesecake gummi bears. Marzipan jujubes sweet roll tootsie roll cookie apple pie brownie bear claw jelly beans.'
      }, {
        title: 'iCell - disrupt butcher pitchfork.',
        linkUrl: 'https://1.envato.market/modern_admin#',
        resultUrl: 'https://1.envato.market/pixinvent_portfolio',
        time: 'Mon DEC 12 2015 08:39:00 GMT+0000 (GMT)',
        description: 'Cake fruitcake cake caramels jelly beans chocolate bar. Macaroon gingerbread pastry. Gummies ice cream chocolate lollipop brownie cotton candy. Topping cotton candy brownie. Cake tiramisu macaroon sugar plum. Sweet cotton candy powder tootsie roll candy gummies brownie lollipop. Sweet muffin pudding.'
      }]
    };
  },
  computed: {
    playerOptions: function playerOptions() {
      return function (media) {
        return {
          height: '360',
          fluid: true,
          // rmeove this comment if you want to autoplay
          // autoplay: true,
          muted: true,
          language: 'en',
          playbackRates: [0.7, 1.0, 1.5, 2.0],
          sources: media.sources,
          poster: media.poster
        };
      };
    }
  },
  methods: {},
  components: {
    videoPlayer: vue_video_player__WEBPACK_IMPORTED_MODULE_0__["videoPlayer"]
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Search.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/Search.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/*=========================================================================================\n    File Name: search.scss\n    Description: Search page styles\n    ----------------------------------------------------------------------------------------\n    Item Name: Vuexy - Vuejs, HTML & Laravel Admin Dashboard Template\n      Author: Pixinvent\n    Author URL: http://www.themeforest.net/user/pixinvent\n==========================================================================================*/\n[dir] .search-tab-filter {\n  padding: 0.5rem 1rem;\n  border-radius: 25px;\n  margin-bottom: 1.5rem;\n  background: #fff;\n  cursor: pointer;\n}\n[dir=ltr] .search-tab-filter {\n  margin-right: 1rem;\n}\n[dir=rtl] .search-tab-filter {\n  margin-left: 1rem;\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Search.vue?vue&type=style&index=0&lang=scss&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/Search.vue?vue&type=style&index=0&lang=scss& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../node_modules/css-loader!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Search.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Search.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Search.vue?vue&type=template&id=06475a06&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/Search.vue?vue&type=template&id=06475a06& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { attrs: { id: "search-page" } }, [
    _c(
      "div",
      { staticClass: "search-page__search-bar flex items-center" },
      [
        _c("vs-input", {
          staticClass: "w-full input-rounded-full",
          attrs: {
            "icon-no-border": "",
            placeholder: "Search",
            icon: "icon-search",
            "icon-pack": "feather"
          },
          model: {
            value: _vm.searchQuery,
            callback: function($$v) {
              _vm.searchQuery = $$v
            },
            expression: "searchQuery"
          }
        })
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass:
          "search-page__serch-menu flex flex-wrap items-center md:justify-between mt-8"
      },
      [
        _c(
          "div",
          { staticClass: "flex flex-wrap" },
          [
            _c("span", { staticClass: "search-tab-filter shadow-drop" }, [
              _vm._v("All")
            ]),
            _vm._v(" "),
            _c("span", { staticClass: "search-tab-filter shadow-drop" }, [
              _vm._v("Images")
            ]),
            _vm._v(" "),
            _c("span", { staticClass: "search-tab-filter shadow-drop" }, [
              _vm._v("Video")
            ]),
            _vm._v(" "),
            _c("span", { staticClass: "search-tab-filter shadow-drop" }, [
              _vm._v("Maps")
            ]),
            _vm._v(" "),
            _c("span", { staticClass: "search-tab-filter shadow-drop" }, [
              _vm._v("News")
            ]),
            _vm._v(" "),
            _c(
              "vs-dropdown",
              {
                staticClass: "search-tab-filter shadow-drop",
                attrs: { "vs-trigger-click": "" }
              },
              [
                _c("span", [_vm._v("More")]),
                _vm._v(" "),
                _c(
                  "vs-dropdown-menu",
                  { staticClass: "search-page__more-dropdown" },
                  [
                    _c("vs-dropdown-item", [_vm._v("Shopping")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Books")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Flight")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Finance")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Personal")])
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          [
            _c(
              "vs-dropdown",
              {
                staticClass: "search-tab-filter shadow-drop",
                attrs: { "vs-trigger-click": "" }
              },
              [
                _c("span", [_vm._v("Settings")]),
                _vm._v(" "),
                _c(
                  "vs-dropdown-menu",
                  { staticClass: "search-page__settings-dropdown w-64" },
                  [
                    _c("vs-dropdown-item", [_vm._v("Search settings")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Language")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Turn on SafeSearch")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Hide Private Results")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Advanced Search")])
                  ],
                  1
                )
              ],
              1
            ),
            _vm._v(" "),
            _c("span", { staticClass: "search-tab-filter mr-0 shadow-drop" }, [
              _vm._v("Tools")
            ])
          ],
          1
        )
      ]
    ),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "search-meta flex flex-wrap justify-between mt-6" },
      [
        _c("span", { staticClass: "mb-4" }, [
          _vm._v("Approx 84,00,00,000 results (0.35s)")
        ]),
        _vm._v(" "),
        _c(
          "div",
          [
            _c(
              "vs-dropdown",
              {
                staticClass: "cursor-pointer",
                attrs: { "vs-trigger-click": "" }
              },
              [
                _c(
                  "span",
                  { staticClass: "flex items-center" },
                  [
                    _c("span", [_vm._v("Any Time")]),
                    _vm._v(" "),
                    _c("feather-icon", {
                      staticClass: "cursor-pointer",
                      staticStyle: { width: "1rem", height: "1rem" },
                      attrs: { icon: "ChevronDownIcon" }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "vs-dropdown-menu",
                  { staticClass: "w-48" },
                  [
                    _c("vs-dropdown-item", [_vm._v("Any Time")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Past Hour")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Past 24 Hours")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Past Week")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Past Month")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Past Year")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Custom Period")])
                  ],
                  1
                )
              ],
              1
            ),
            _vm._v("\n             \n            "),
            _c(
              "vs-dropdown",
              {
                staticClass: "cursor-pointer",
                attrs: { "vs-trigger-click": "" }
              },
              [
                _c(
                  "span",
                  { staticClass: "flex items-center" },
                  [
                    _c("span", [_vm._v("All Results")]),
                    _vm._v(" "),
                    _c("feather-icon", {
                      staticClass: "cursor-pointer",
                      staticStyle: { width: "1rem", height: "1rem" },
                      attrs: { icon: "ChevronDownIcon" }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "vs-dropdown-menu",
                  { staticClass: "w-32" },
                  [
                    _c("vs-dropdown-item", [_vm._v("All Result")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v("Verbatim")])
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        )
      ]
    ),
    _vm._v(" "),
    _c("div", { staticClass: "vx-row mt-4 md:flex-row flex-col-reverse" }, [
      _c(
        "div",
        { staticClass: "vx-col md:w-3/5 lg:w-2/3 w-full" },
        [
          _c(
            "vx-card",
            { staticClass: "search-page__search-results lg:p-2" },
            _vm._l(_vm.searchResults, function(result, index) {
              return _c(
                "div",
                {
                  key: index,
                  staticClass: "vx-row search-Page__search-result",
                  class: { "mt-8": index }
                },
                [
                  result.resultImg || result.resultVideo
                    ? _c(
                        "div",
                        {
                          staticClass: "vx-col mb-2",
                          class:
                            result.resultImg || result.resultVideo
                              ? "lg:w-1/5 md:w-1/4 w-full"
                              : "w-full"
                        },
                        [
                          result.resultImg
                            ? _c("img", {
                                staticClass: "responsive",
                                attrs: {
                                  src: result.resultImg,
                                  alt: "result-img"
                                }
                              })
                            : result.resultVideo
                            ? _c("video-player", {
                                ref: "player",
                                refInFor: true,
                                staticClass: "media-video-player",
                                attrs: {
                                  options: _vm.playerOptions(
                                    result.resultVideo[0]
                                  )
                                }
                              })
                            : _vm._e()
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass: "vx-col",
                      class:
                        result.resultImg || result.resultVideo
                          ? "lg:w-4/5 md:w-3/4"
                          : "w-full"
                    },
                    [
                      _c(
                        "a",
                        {
                          staticClass: "inline-block text-2xl",
                          attrs: {
                            href: result.linkUrl,
                            target: "_blank",
                            rel: "nofollow"
                          }
                        },
                        [_vm._v(_vm._s(result.title))]
                      ),
                      _c("br"),
                      _vm._v(" "),
                      _c(
                        "a",
                        {
                          staticClass: "inline-block text-success mb-1",
                          attrs: {
                            href: result.resultUrl,
                            target: "_blank",
                            rel: "nofollow"
                          }
                        },
                        [_vm._v(_vm._s(result.resultUrl))]
                      ),
                      _c("br"),
                      _vm._v(" "),
                      result.metaData
                        ? _c(
                            "div",
                            {
                              staticClass:
                                "flex flex-wrap items-center search-page__search-result-meta my-1"
                            },
                            [
                              result.metaData.ratings
                                ? _c(
                                    "div",
                                    {
                                      staticClass:
                                        "flex items-center search-page__search-result-ratings mr-3"
                                    },
                                    [
                                      _vm._l(
                                        Math.floor(result.metaData.ratings),
                                        function(i) {
                                          return _c("img", {
                                            key: i,
                                            staticClass: "mb-1",
                                            attrs: {
                                              src: __webpack_require__(/*! @assets/images/raty/star-on-2.png */ "./resources/assets/images/raty/star-on-2.png"),
                                              alt: "rating"
                                            }
                                          })
                                        }
                                      ),
                                      _vm._v(" "),
                                      result.metaData.ratings % 1
                                        ? _c("img", {
                                            staticClass: "mb-1",
                                            attrs: {
                                              src: __webpack_require__(/*! @assets/images/raty/star-half-2.png */ "./resources/assets/images/raty/star-half-2.png"),
                                              alt: "rating"
                                            }
                                          })
                                        : _vm._e()
                                    ],
                                    2
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _c(
                                "div",
                                _vm._l(result.metaData.info, function(
                                  info,
                                  infoIndex
                                ) {
                                  return _c(
                                    "span",
                                    { key: infoIndex, staticClass: "mr-2" },
                                    [
                                      _vm._v(_vm._s(info) + " "),
                                      infoIndex <
                                      result.metaData.info.length - 1
                                        ? _c("span", [_vm._v("|")])
                                        : _vm._e()
                                    ]
                                  )
                                }),
                                0
                              )
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      result.time
                        ? _c("span", [
                            _vm._v(
                              _vm._s(_vm._f("date")(result.time, true)) + " - "
                            )
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      _c("span", [
                        _vm._v(
                          _vm._s(
                            _vm._f("tailing")(
                              _vm._f("truncate")(result.description, 225),
                              "..."
                            )
                          )
                        )
                      ]),
                      _vm._v(" "),
                      result.sitelinks
                        ? _c(
                            "div",
                            { staticClass: "vx-row mt-6" },
                            _vm._l(result.sitelinks, function(sitelink, index) {
                              return _c(
                                "div",
                                {
                                  key: index,
                                  staticClass:
                                    "vx-col w-full sm:w-1/2 lg:w-1/3 mb-5"
                                },
                                [
                                  _c(
                                    "a",
                                    {
                                      staticClass: "inline-block mb-1",
                                      attrs: {
                                        href: sitelink.url,
                                        target: "_blank",
                                        rel: "nofollow"
                                      }
                                    },
                                    [_vm._v(_vm._s(sitelink.title))]
                                  ),
                                  _c("br"),
                                  _vm._v(" "),
                                  _c("p", [
                                    _vm._v(
                                      _vm._s(
                                        _vm._f("tailing")(
                                          _vm._f("truncate")(
                                            sitelink.description,
                                            50
                                          ),
                                          "..."
                                        )
                                      )
                                    )
                                  ])
                                ]
                              )
                            }),
                            0
                          )
                        : _vm._e()
                    ]
                  )
                ]
              )
            }),
            0
          ),
          _vm._v(" "),
          _c("vs-pagination", {
            staticClass: "mt-base",
            attrs: { total: 40 },
            model: {
              value: _vm.currentPage,
              callback: function($$v) {
                _vm.currentPage = $$v
              },
              expression: "currentPage"
            }
          })
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "vx-col md:w-2/5 lg:w-1/3 w-full mb-base" },
        [
          _c(
            "vx-card",
            {
              staticClass: "bg-transparent no-shadow",
              attrs: { "card-border": "" }
            },
            [
              _c(
                "div",
                { staticClass: "search-page__search-img-gallery vx-row mb-4" },
                [
                  _c("div", { staticClass: "vx-col w-full" }, [
                    _c("img", {
                      staticClass: "responsive shadow-md rounded-lg",
                      attrs: { src: _vm.knowledgePanel.img, alt: "gallery-img" }
                    })
                  ])
                ]
              ),
              _vm._v(" "),
              _c("h3", [_vm._v(_vm._s(_vm.knowledgePanel.title))]),
              _vm._v(" "),
              _c("small", [_vm._v(_vm._s(_vm.knowledgePanel.subtitle))]),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "knowledgePanel__external-link flex my-2" },
                [
                  _c("feather-icon", {
                    attrs: {
                      icon: _vm.knowledgePanel.externalLink.icon,
                      svgClasses: "w-4 h-4 mb-1 mr-2"
                    }
                  }),
                  _vm._v(" "),
                  _c(
                    "a",
                    {
                      attrs: {
                        href: _vm.knowledgePanel.externalLink.url,
                        target: "_blank",
                        rel: "nofollow"
                      }
                    },
                    [_vm._v(_vm._s(_vm.knowledgePanel.externalLink.title))]
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c("p", [_vm._v(_vm._s(_vm.knowledgePanel.description))]),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "knowledge-panel__info-list flex mt-6" },
                _vm._l(_vm.knowledgePanel.info, function(info, index) {
                  return _c(
                    "div",
                    {
                      key: info.title,
                      staticClass:
                        "knowledge-panel__info flex-1 text-center border-solid border-grey-light border border-r-0 border-b-0 border-t-0",
                      class: { "border-l-0": index == 0 }
                    },
                    [
                      _c("p", { staticClass: "font-medium" }, [
                        _vm._v(_vm._s(info.title))
                      ]),
                      _vm._v(" "),
                      _c("small", [_vm._v(_vm._s(info.subtitle))])
                    ]
                  )
                }),
                0
              ),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "knowledge-panel__meta-list mt-6" },
                _vm._l(_vm.knowledgePanel.resultMetaList, function(meta) {
                  return _c(
                    "div",
                    { key: meta.name, staticClass: "knowledge-panel__meta" },
                    [
                      _c("p", [
                        _c("span", { staticClass: "font-medium mr-2" }, [
                          _vm._v(_vm._s(meta.name) + ":")
                        ]),
                        _vm._v(" " + _vm._s(meta.value))
                      ])
                    ]
                  )
                }),
                0
              ),
              _vm._v(" "),
              _c("div", { staticClass: "knowledge-panel-suggestions mt-6" }, [
                _c("p", { staticClass: "text-lg font-medium mb-2" }, [
                  _vm._v("People also search for")
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass:
                      "knowledge-panel__suggested-list flex flex-wrap"
                  },
                  _vm._l(_vm.knowledgePanel.suggestedSearches, function(
                    search
                  ) {
                    return _c(
                      "div",
                      {
                        key: search.name,
                        staticClass:
                          "knowledge-panel__suggestion mr-4 text-center"
                      },
                      [
                        _c(
                          "a",
                          {
                            attrs: {
                              href: search.url,
                              target: "_blank",
                              rel: "nofollow"
                            }
                          },
                          [
                            _c("img", {
                              staticClass: "mx-auto",
                              attrs: {
                                src: search.img,
                                alt: "suggested-search-img",
                                height: "40px",
                                width: "40px"
                              }
                            })
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "a",
                          {
                            staticClass: "text-sm",
                            attrs: {
                              href: search.url,
                              target: "_blank",
                              rel: "nofollow"
                            }
                          },
                          [_vm._v(_vm._s(search.name))]
                        )
                      ]
                    )
                  }),
                  0
                )
              ])
            ]
          )
        ],
        1
      )
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/assets/images/pages/1-apex.png":
/*!**************************************************!*\
  !*** ./resources/assets/images/pages/1-apex.png ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/1-apex.png?5e2bf309d37d0fa88ae4e495f963bc8e";

/***/ }),

/***/ "./resources/assets/images/pages/2-stack.png":
/*!***************************************************!*\
  !*** ./resources/assets/images/pages/2-stack.png ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/2-stack.png?425adc71b4f5585dd1ec288605361f8e";

/***/ }),

/***/ "./resources/assets/images/pages/3-convex.png":
/*!****************************************************!*\
  !*** ./resources/assets/images/pages/3-convex.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/3-convex.png?d311fc09e6c63db312c77e1673888929";

/***/ }),

/***/ "./resources/assets/images/pages/4-materialize.png":
/*!*********************************************************!*\
  !*** ./resources/assets/images/pages/4-materialize.png ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/4-materialize.png?f4f276c2b03a7551daf57b30fb50d641";

/***/ }),

/***/ "./resources/assets/images/pages/modern.jpg":
/*!**************************************************!*\
  !*** ./resources/assets/images/pages/modern.jpg ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/modern.jpg?cb09b5bd1e85ef2f24af93a629bcdf93";

/***/ }),

/***/ "./resources/assets/images/pages/search-result.jpg":
/*!*********************************************************!*\
  !*** ./resources/assets/images/pages/search-result.jpg ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/search-result.jpg?94483d7a3a5f6222a3901c25c16cb811";

/***/ }),

/***/ "./resources/assets/images/raty/star-half-2.png":
/*!******************************************************!*\
  !*** ./resources/assets/images/raty/star-half-2.png ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/star-half-2.png?061994cfb3818d8236538862142171c0";

/***/ }),

/***/ "./resources/assets/images/raty/star-on-2.png":
/*!****************************************************!*\
  !*** ./resources/assets/images/raty/star-on-2.png ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/star-on-2.png?527610a86010ef0621c288a3c6bb7b54";

/***/ }),

/***/ "./resources/js/src/views/pages/Search.vue":
/*!*************************************************!*\
  !*** ./resources/js/src/views/pages/Search.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Search_vue_vue_type_template_id_06475a06___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Search.vue?vue&type=template&id=06475a06& */ "./resources/js/src/views/pages/Search.vue?vue&type=template&id=06475a06&");
/* harmony import */ var _Search_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Search.vue?vue&type=script&lang=js& */ "./resources/js/src/views/pages/Search.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Search_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Search.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/pages/Search.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Search_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Search_vue_vue_type_template_id_06475a06___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Search_vue_vue_type_template_id_06475a06___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/pages/Search.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/pages/Search.vue?vue&type=script&lang=js&":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/pages/Search.vue?vue&type=script&lang=js& ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Search.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Search.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/pages/Search.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************!*\
  !*** ./resources/js/src/views/pages/Search.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader!../../../../../node_modules/css-loader!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Search.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Search.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/src/views/pages/Search.vue?vue&type=template&id=06475a06&":
/*!********************************************************************************!*\
  !*** ./resources/js/src/views/pages/Search.vue?vue&type=template&id=06475a06& ***!
  \********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_template_id_06475a06___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Search.vue?vue&type=template&id=06475a06& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/Search.vue?vue&type=template&id=06475a06&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_template_id_06475a06___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Search_vue_vue_type_template_id_06475a06___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ 7:
/*!******************************!*\
  !*** min-document (ignored) ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

}]);