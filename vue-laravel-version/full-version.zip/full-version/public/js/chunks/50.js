(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[50],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NavbarDefault_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavbarDefault.vue */ "./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue");
/* harmony import */ var _NavbarInput_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavbarInput.vue */ "./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue");
/* harmony import */ var _NavbarType_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./NavbarType.vue */ "./resources/js/src/views/components/vuesax/navbar/NavbarType.vue");
/* harmony import */ var _NavbarColor_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavbarColor.vue */ "./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue");
/* harmony import */ var _NavbarCollapse_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./NavbarCollapse.vue */ "./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    NavbarDefault: _NavbarDefault_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    NavbarInput: _NavbarInput_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    NavbarType: _NavbarType_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    NavbarCollapse: _NavbarCollapse_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    NavbarColor: _NavbarColor_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      activeItem: 0
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      colorx: '#5A8DEE',
      indexActive: 0
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      activeItem: 0
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      activeItem: 0,
      search: ''
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      activeItem: 0,
      type: 'gradient',
      types: [{
        value: null,
        text: 'Default'
      }, {
        value: 'flat',
        text: 'Flat'
      }, {
        value: 'fund',
        text: 'Fund'
      }, {
        value: 'border',
        text: 'border'
      }, {
        value: 'gradient',
        text: 'Gradient'
      }, {
        value: 'shadow',
        text: 'Shadow'
      }]
    };
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=template&id=63ef14ba&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=template&id=63ef14ba& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "navbar-demo" } },
    [
      _c("navbar-default"),
      _vm._v(" "),
      _c("navbar-input"),
      _vm._v(" "),
      _c("navbar-type"),
      _vm._v(" "),
      _c("navbar-color"),
      _vm._v(" "),
      _c("navbar-collapse")
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=template&id=45e113f0&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=template&id=45e113f0& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Collapse", "code-toggler": "" } },
    [
      _c("p", [
        _c("code", [_vm._v("collapse")]),
        _vm._v(
          " property determines if the component starts hidden and with the option of clicking on the menu to open or show the options"
        )
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c(
            "vs-navbar",
            {
              staticClass: "p-2",
              attrs: { collapse: "" },
              model: {
                value: _vm.activeItem,
                callback: function($$v) {
                  _vm.activeItem = $$v
                },
                expression: "activeItem"
              }
            },
            [
              _c(
                "div",
                { attrs: { slot: "title" }, slot: "title" },
                [_c("vs-navbar-title", [_c("span", [_vm._v("Vuexy")])])],
                1
              ),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "0" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("Home")])
              ]),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "1" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("News")])
              ]),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "2" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("Update")])
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <vs-navbar collapse v-model="activeItem" class="p-2">\n\n    <div slot="title">\n      <vs-navbar-title>\n        <span>Vuexy</span>\n      </vs-navbar-title>\n    </div>\n\n    <vs-navbar-item index="0">\n      <a href="#">Home</a>\n    </vs-navbar-item>\n\n    <vs-navbar-item index="1">\n      <a href="#">News</a>\n    </vs-navbar-item>\n\n    <vs-navbar-item index="2">\n      <a href="#">Update</a>\n    </vs-navbar-item>\n  </vs-navbar>\n</template>\n\n<script>\nexport default {\n  data: () => ({\n    activeItem: 0\n  })\n}\n</script>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=template&id=01e90430&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=template&id=01e90430& ***!
  \**************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Color", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("You can change the color of the Topbar with the property "),
        _c("code", [_vm._v("color")]),
        _vm._v(". You are able to use the Main Colors or RGB and HEX colors")
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { icon: "warning", active: "true", color: "warning" }
        },
        [
          _c("span", [
            _vm._v("Only "),
            _c("strong", [_vm._v("RGB")]),
            _vm._v(" and "),
            _c("strong", [_vm._v("HEX")]),
            _vm._v(" colors are supported.")
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        [
          _c(
            "div",
            { staticClass: "demo-alignment my-5" },
            [
              _c(
                "vs-radio",
                {
                  attrs: { "vs-value": "primary" },
                  model: {
                    value: _vm.colorx,
                    callback: function($$v) {
                      _vm.colorx = $$v
                    },
                    expression: "colorx"
                  }
                },
                [_vm._v("Primary")]
              ),
              _vm._v(" "),
              _c(
                "vs-radio",
                {
                  attrs: { color: "danger", "vs-value": "danger" },
                  model: {
                    value: _vm.colorx,
                    callback: function($$v) {
                      _vm.colorx = $$v
                    },
                    expression: "colorx"
                  }
                },
                [_vm._v("Danger")]
              ),
              _vm._v(" "),
              _c(
                "vs-radio",
                {
                  attrs: { color: "success", "vs-value": "success" },
                  model: {
                    value: _vm.colorx,
                    callback: function($$v) {
                      _vm.colorx = $$v
                    },
                    expression: "colorx"
                  }
                },
                [_vm._v("Success")]
              ),
              _vm._v(" "),
              _c(
                "vs-radio",
                {
                  attrs: { color: "warning", "vs-value": "warning" },
                  model: {
                    value: _vm.colorx,
                    callback: function($$v) {
                      _vm.colorx = $$v
                    },
                    expression: "colorx"
                  }
                },
                [_vm._v("Warning")]
              ),
              _vm._v(" "),
              _c(
                "vs-radio",
                {
                  attrs: { color: "dark", "vs-value": "dark" },
                  model: {
                    value: _vm.colorx,
                    callback: function($$v) {
                      _vm.colorx = $$v
                    },
                    expression: "colorx"
                  }
                },
                [_vm._v("Dark")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.colorx,
                    expression: "colorx"
                  }
                ],
                staticClass: "input-color",
                attrs: { type: "color" },
                domProps: { value: _vm.colorx },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.colorx = $event.target.value
                  }
                }
              })
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "vs-navbar",
            {
              staticClass: "myNavbar text-white",
              attrs: {
                color: _vm.colorx,
                "text-color": "rgba(255,255,255,.6)",
                "active-text-color": "rgba(255,255,255,1)"
              },
              model: {
                value: _vm.indexActive,
                callback: function($$v) {
                  _vm.indexActive = $$v
                },
                expression: "indexActive"
              }
            },
            [
              _c(
                "div",
                { attrs: { slot: "title" }, slot: "title" },
                [
                  _c("vs-navbar-title", [
                    _vm._v(
                      "\n                        Navbar Color\n                    "
                    )
                  ])
                ],
                1
              ),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "0" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("Home")])
              ]),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "1" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("News")])
              ]),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "2" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("Update")])
              ]),
              _vm._v(" "),
              _c("vs-spacer"),
              _vm._v(" "),
              _c("vs-button", {
                attrs: {
                  "color-text": "rgb(255, 255, 255)",
                  color: "rgba(255, 255, 255, 0.3)",
                  type: "flat",
                  icon: "more_horiz"
                }
              })
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n\n  <input class="input-color" v-model="colorx" type="color">\n  <vs-navbar v-model="indexActive" :color="colorx" text-color="rgba(255,255,255,.6)" active-text-color="rgba(255,255,255,1)" class="myNavbar text-white">\n    <div slot="title">\n      <vs-navbar-title>\n        Navbar Color\n      </vs-navbar-title>\n    </div>\n\n    <vs-navbar-item index="0">\n      <a href="#">Home</a>\n    </vs-navbar-item>\n\n    <vs-navbar-item index="1">\n      <a href="#">News</a>\n    </vs-navbar-item>\n\n    <vs-navbar-item index="2">\n      <a href="#">Update</a>\n    </vs-navbar-item>\n\n    <vs-spacer></vs-spacer>\n\n    <vs-button color-text="rgb(255, 255, 255)" color="rgba(255, 255, 255, 0.3)" type="flat" icon="more_horiz"></vs-button>\n  </vs-navbar>\n</template>\n\n<script>\nexport default {\n  data: ()=>({\n    colorx:\'#5A8DEE\',\n    indexActive: 0\n  })\n}\n</script>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=template&id=1616f2ce&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=template&id=1616f2ce& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Default", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("To add a navbar we have the component "),
        _c("code", [_vm._v("vs-navbar")]),
        _vm._v(
          ", there is a series of sub components to determine internal elements "
        ),
        _c("code", [_vm._v("vs-navbar-title")]),
        _vm._v(", "),
        _c("code", [_vm._v("vs-spacer")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c(
            "vs-navbar",
            {
              staticClass: "p-2",
              model: {
                value: _vm.activeItem,
                callback: function($$v) {
                  _vm.activeItem = $$v
                },
                expression: "activeItem"
              }
            },
            [
              _c(
                "div",
                { attrs: { slot: "title" }, slot: "title" },
                [_c("vs-navbar-title", [_c("span", [_vm._v("Vuexy")])])],
                1
              ),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "0" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("Home")])
              ]),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "1" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("News")])
              ]),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "2" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("Update")])
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <vs-navbar v-model="activeItem" class="p-2">\n\n    <div slot="title">\n      <vs-navbar-title>\n        <span>Vuexy</span>\n      </vs-navbar-title>\n    </div>\n\n    <vs-navbar-item index="0">\n      <a href="#">Home</a>\n    </vs-navbar-item>\n\n    <vs-navbar-item index="1">\n      <a href="#">News</a>\n    </vs-navbar-item>\n\n    <vs-navbar-item index="2">\n      <a href="#">Update</a>\n    </vs-navbar-item>\n  </vs-navbar>\n</template>\n\n<script>\nexport default {\n  data: () => ({\n    activeItem: 0\n  })\n}\n</script>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=template&id=1cd6bdd2&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=template&id=1cd6bdd2& ***!
  \**************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Input", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("You may need an entry in the menu to simply use the "),
        _c("code", [_vm._v("vs-input")]),
        _vm._v(" component, for example if you need a search engine")
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c(
            "vs-navbar",
            {
              staticClass: "p-2",
              model: {
                value: _vm.activeItem,
                callback: function($$v) {
                  _vm.activeItem = $$v
                },
                expression: "activeItem"
              }
            },
            [
              _c(
                "div",
                { attrs: { slot: "title" }, slot: "title" },
                [_c("vs-navbar-title", [_c("span", [_vm._v("Vuexy")])])],
                1
              ),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "0" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("Home")])
              ]),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "1" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("News")])
              ]),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "2" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("Update")])
              ]),
              _vm._v(" "),
              _c("vs-input", {
                staticClass: "input-rounded-full",
                attrs: {
                  "icon-pack": "feather",
                  icon: "icon-search",
                  placeholder: "Search",
                  "icon-no-border": "",
                  size: "small"
                },
                model: {
                  value: _vm.search,
                  callback: function($$v) {
                    _vm.search = $$v
                  },
                  expression: "search"
                }
              })
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <vs-navbar v-model="activeItem" class="p-2">\n\n    <div slot="title">\n      <vs-navbar-title>\n        <span>Vuexy</span>\n      </vs-navbar-title>\n    </div>\n\n    <vs-navbar-item index="0">\n      <a href="#">Home</a>\n    </vs-navbar-item>\n\n    <vs-navbar-item index="1">\n      <a href="#">News</a>\n    </vs-navbar-item>\n\n    <vs-navbar-item index="2">\n      <a href="#">Update</a>\n    </vs-navbar-item>\n\n    <vs-input icon-pack="feather" icon="icon-search" placeholder="Search" v-model="search" />\n  </vs-navbar>\n</template>\n\n<script>\nexport default {\n  data: () => ({\n    activeItem: 0,\n    search: "",\n  })\n}\n</script>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=template&id=056cbe7d&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=template&id=056cbe7d& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Type", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "If you want you can change the style of the buttons and the navbar by changing the property "
        ),
        _c("code", [_vm._v("type")])
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c(
            "vs-select",
            {
              staticClass: "selectExample mb-5",
              attrs: { label: "Figuras" },
              model: {
                value: _vm.type,
                callback: function($$v) {
                  _vm.type = $$v
                },
                expression: "type"
              }
            },
            _vm._l(_vm.types, function(item, index) {
              return _c("vs-select-item", {
                key: index,
                attrs: { value: item.value, text: item.text }
              })
            }),
            1
          ),
          _vm._v(" "),
          _c(
            "vs-navbar",
            {
              staticClass: "p-2",
              attrs: { type: _vm.type },
              model: {
                value: _vm.activeItem,
                callback: function($$v) {
                  _vm.activeItem = $$v
                },
                expression: "activeItem"
              }
            },
            [
              _c(
                "div",
                { attrs: { slot: "title" }, slot: "title" },
                [
                  _c("vs-navbar-title", [
                    _c("span", [_vm._v("Type " + _vm._s(_vm.type))])
                  ])
                ],
                1
              ),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "0" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("Home")])
              ]),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "1" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("News")])
              ]),
              _vm._v(" "),
              _c("vs-navbar-item", { attrs: { index: "2" } }, [
                _c("a", { attrs: { href: "#" } }, [_vm._v("Update")])
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <div>\n    <vs-select class="selectExample mb-5" label="Figuras" v-model="type" class="p-2">\n      <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in types" />\n    </vs-select>\n\n    <vs-navbar :type="type" v-model="activeItem" class="nabarx">\n\n      <div slot="title">\n        <vs-navbar-title>\n          <span>Type ' +
            _vm._s("{{ type }}") +
            "</span>\n        </vs-navbar-title>\n      </div>\n\n      <vs-navbar-item index=\"0\">\n        <a href=\"#\">Home</a>\n      </vs-navbar-item>\n\n      <vs-navbar-item index=\"1\">\n        <a href=\"#\">News</a>\n      </vs-navbar-item>\n\n      <vs-navbar-item index=\"2\">\n        <a href=\"#\">Update</a>\n      </vs-navbar-item>\n    </vs-navbar>\n  </div>\n</template>\n\n<script>\nexport default {\n  data: () => ({\n    activeItem: 0,\n    type: 'flat',\n    types: [{\n        value: null,\n        text: 'Default'\n      },\n      {\n        value: 'flat',\n        text: 'Flat'\n      },\n      {\n        value: 'fund',\n        text: 'Fund'\n      },\n      {\n        value: 'border',\n        text: 'border'\n      },\n      {\n        value: 'gradient',\n        text: 'Gradient'\n      },\n      {\n        value: 'shadow',\n        text: 'Shadow'\n      }\n    ]\n  })\n}\n</script>\n        "
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/Navbar.vue":
/*!********************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/Navbar.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Navbar_vue_vue_type_template_id_63ef14ba___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Navbar.vue?vue&type=template&id=63ef14ba& */ "./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=template&id=63ef14ba&");
/* harmony import */ var _Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Navbar.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Navbar_vue_vue_type_template_id_63ef14ba___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Navbar_vue_vue_type_template_id_63ef14ba___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/navbar/Navbar.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Navbar.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=template&id=63ef14ba&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=template&id=63ef14ba& ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_template_id_63ef14ba___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Navbar.vue?vue&type=template&id=63ef14ba& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/Navbar.vue?vue&type=template&id=63ef14ba&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_template_id_63ef14ba___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_template_id_63ef14ba___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NavbarCollapse_vue_vue_type_template_id_45e113f0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavbarCollapse.vue?vue&type=template&id=45e113f0& */ "./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=template&id=45e113f0&");
/* harmony import */ var _NavbarCollapse_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavbarCollapse.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _NavbarCollapse_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _NavbarCollapse_vue_vue_type_template_id_45e113f0___WEBPACK_IMPORTED_MODULE_0__["render"],
  _NavbarCollapse_vue_vue_type_template_id_45e113f0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarCollapse_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarCollapse.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarCollapse_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=template&id=45e113f0&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=template&id=45e113f0& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarCollapse_vue_vue_type_template_id_45e113f0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarCollapse.vue?vue&type=template&id=45e113f0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarCollapse.vue?vue&type=template&id=45e113f0&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarCollapse_vue_vue_type_template_id_45e113f0___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarCollapse_vue_vue_type_template_id_45e113f0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue":
/*!*************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NavbarColor_vue_vue_type_template_id_01e90430___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavbarColor.vue?vue&type=template&id=01e90430& */ "./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=template&id=01e90430&");
/* harmony import */ var _NavbarColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavbarColor.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _NavbarColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _NavbarColor_vue_vue_type_template_id_01e90430___WEBPACK_IMPORTED_MODULE_0__["render"],
  _NavbarColor_vue_vue_type_template_id_01e90430___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/navbar/NavbarColor.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarColor.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=template&id=01e90430&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=template&id=01e90430& ***!
  \********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarColor_vue_vue_type_template_id_01e90430___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarColor.vue?vue&type=template&id=01e90430& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarColor.vue?vue&type=template&id=01e90430&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarColor_vue_vue_type_template_id_01e90430___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarColor_vue_vue_type_template_id_01e90430___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NavbarDefault_vue_vue_type_template_id_1616f2ce___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavbarDefault.vue?vue&type=template&id=1616f2ce& */ "./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=template&id=1616f2ce&");
/* harmony import */ var _NavbarDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavbarDefault.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _NavbarDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _NavbarDefault_vue_vue_type_template_id_1616f2ce___WEBPACK_IMPORTED_MODULE_0__["render"],
  _NavbarDefault_vue_vue_type_template_id_1616f2ce___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarDefault.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=template&id=1616f2ce&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=template&id=1616f2ce& ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarDefault_vue_vue_type_template_id_1616f2ce___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarDefault.vue?vue&type=template&id=1616f2ce& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarDefault.vue?vue&type=template&id=1616f2ce&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarDefault_vue_vue_type_template_id_1616f2ce___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarDefault_vue_vue_type_template_id_1616f2ce___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue":
/*!*************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NavbarInput_vue_vue_type_template_id_1cd6bdd2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavbarInput.vue?vue&type=template&id=1cd6bdd2& */ "./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=template&id=1cd6bdd2&");
/* harmony import */ var _NavbarInput_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavbarInput.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _NavbarInput_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _NavbarInput_vue_vue_type_template_id_1cd6bdd2___WEBPACK_IMPORTED_MODULE_0__["render"],
  _NavbarInput_vue_vue_type_template_id_1cd6bdd2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/navbar/NavbarInput.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarInput_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarInput.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarInput_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=template&id=1cd6bdd2&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=template&id=1cd6bdd2& ***!
  \********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarInput_vue_vue_type_template_id_1cd6bdd2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarInput.vue?vue&type=template&id=1cd6bdd2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarInput.vue?vue&type=template&id=1cd6bdd2&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarInput_vue_vue_type_template_id_1cd6bdd2___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarInput_vue_vue_type_template_id_1cd6bdd2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarType.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarType.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NavbarType_vue_vue_type_template_id_056cbe7d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavbarType.vue?vue&type=template&id=056cbe7d& */ "./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=template&id=056cbe7d&");
/* harmony import */ var _NavbarType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavbarType.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _NavbarType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _NavbarType_vue_vue_type_template_id_056cbe7d___WEBPACK_IMPORTED_MODULE_0__["render"],
  _NavbarType_vue_vue_type_template_id_056cbe7d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/navbar/NavbarType.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarType.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarType_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=template&id=056cbe7d&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=template&id=056cbe7d& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarType_vue_vue_type_template_id_056cbe7d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarType.vue?vue&type=template&id=056cbe7d& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/navbar/NavbarType.vue?vue&type=template&id=056cbe7d&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarType_vue_vue_type_template_id_056cbe7d___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarType_vue_vue_type_template_id_056cbe7d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);