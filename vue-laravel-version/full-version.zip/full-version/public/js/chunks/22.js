(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[22],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselDefault_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselDefault.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue");
/* harmony import */ var _CarouselNavigation_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselNavigation.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue");
/* harmony import */ var _CarouselPagination_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CarouselPagination.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue");
/* harmony import */ var _CarouselProgress_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CarouselProgress.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue");
/* harmony import */ var _CarouselMultipleSlidesPerView_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CarouselMultipleSlidesPerView.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue");
/* harmony import */ var _CarouselMultiRowSlidesLayout_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./CarouselMultiRowSlidesLayout.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue");
/* harmony import */ var _CarouselEffectFade_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./CarouselEffectFade.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue");
/* harmony import */ var _Carousel3dEffect_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Carousel3dEffect.vue */ "./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue");
/* harmony import */ var _Carousel3dCoverflowEffect_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Carousel3dCoverflowEffect.vue */ "./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue");
/* harmony import */ var _CarouselAutoplay_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./CarouselAutoplay.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue");
/* harmony import */ var _CarouselGallery_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./CarouselGallery.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue");
/* harmony import */ var _CarouselParallax_vue__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./CarouselParallax.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue");
/* harmony import */ var _CarouselLazyLoading_vue__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./CarouselLazyLoading.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue");
/* harmony import */ var _CarouselResponsiveBreakpoints_vue__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./CarouselResponsiveBreakpoints.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue");
/* harmony import */ var _CarouselVirtualSlides_vue__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./CarouselVirtualSlides.vue */ "./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//















/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    CarouselDefault: _CarouselDefault_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    CarouselNavigation: _CarouselNavigation_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    CarouselPagination: _CarouselPagination_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    CarouselProgress: _CarouselProgress_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    CarouselMultipleSlidesPerView: _CarouselMultipleSlidesPerView_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    CarouselMultiRowSlidesLayout: _CarouselMultiRowSlidesLayout_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    CarouselEffectFade: _CarouselEffectFade_vue__WEBPACK_IMPORTED_MODULE_6__["default"],
    Carousel3dEffect: _Carousel3dEffect_vue__WEBPACK_IMPORTED_MODULE_7__["default"],
    Carousel3dCoverflowEffect: _Carousel3dCoverflowEffect_vue__WEBPACK_IMPORTED_MODULE_8__["default"],
    CarouselAutoplay: _CarouselAutoplay_vue__WEBPACK_IMPORTED_MODULE_9__["default"],
    CarouselGallery: _CarouselGallery_vue__WEBPACK_IMPORTED_MODULE_10__["default"],
    CarouselParallax: _CarouselParallax_vue__WEBPACK_IMPORTED_MODULE_11__["default"],
    CarouselLazyLoading: _CarouselLazyLoading_vue__WEBPACK_IMPORTED_MODULE_12__["default"],
    CarouselResponsiveBreakpoints: _CarouselResponsiveBreakpoints_vue__WEBPACK_IMPORTED_MODULE_13__["default"],
    CarouselVirtualSlides: _CarouselVirtualSlides_vue__WEBPACK_IMPORTED_MODULE_14__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        effect: 'coverflow',
        grabCursor: true,
        centeredSlides: true,
        slidesPerView: 'auto',
        coverflowEffect: {
          rotate: 50,
          stretch: 0,
          depth: 100,
          modifier: 1,
          slideShadows: true
        },
        pagination: {
          el: '.swiper-pagination'
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        effect: 'cube',
        grabCursor: true,
        cubeEffect: {
          shadow: true,
          slideShadows: true,
          shadowOffset: 20,
          shadowScale: 0.94
        },
        pagination: {
          el: '.swiper-pagination'
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: {
          delay: 2500,
          disableOnInteraction: false
        },
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        spaceBetween: 30,
        effect: 'fade',
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOptionTop: {
        spaceBetween: 10,
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      },
      swiperOptionThumbs: {
        spaceBetween: 10,
        centeredSlides: true,
        slidesPerView: 'auto',
        touchRatio: 0.2,
        slideToClickedSlide: true
      }
    };
  },
  mounted: function mounted() {
    var _this = this;

    this.$nextTick(function () {
      var swiperTop = _this.$refs.swiperTop.swiper;
      var swiperThumbs = _this.$refs.swiperThumbs.swiper;
      swiperTop.controller.control = swiperThumbs;
      swiperThumbs.controller.control = swiperTop;
    });
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        // Enable lazy loading
        lazy: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      },
      slides: [{
        img: __webpack_require__(/*! @assets/images/pages/carousel/banner-13.jpg */ "./resources/assets/images/pages/carousel/banner-13.jpg")
      }, {
        img: __webpack_require__(/*! @assets/images/pages/carousel/banner-7.jpg */ "./resources/assets/images/pages/carousel/banner-7.jpg")
      }, {
        img: __webpack_require__(/*! @assets/images/pages/carousel/banner-10.jpg */ "./resources/assets/images/pages/carousel/banner-10.jpg")
      }, {
        img: __webpack_require__(/*! @assets/images/pages/carousel/banner-16.jpg */ "./resources/assets/images/pages/carousel/banner-16.jpg")
      }, {
        img: __webpack_require__(/*! @assets/images/pages/carousel/banner-20.jpg */ "./resources/assets/images/pages/carousel/banner-20.jpg")
      }]
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        slidesPerView: 3,
        slidesPerColumn: 2,
        spaceBetween: 30,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        breakpoints: {
          1024: {
            slidesPerView: 3,
            spaceBetween: 40
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 30
          },
          640: {
            slidesPerView: 1,
            spaceBetween: 20
          }
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        slidesPerView: 3,
        spaceBetween: 30,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        breakpoints: {
          1024: {
            slidesPerView: 3,
            spaceBetween: 40
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 30
          },
          640: {
            slidesPerView: 1,
            spaceBetween: 20
          }
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        pagination: {
          el: '.swiper-pagination'
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        speed: 600,
        parallax: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        pagination: {
          el: '.swiper-pagination',
          type: 'progressbar'
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      swiperOption: {
        slidesPerView: 5,
        spaceBetween: 50,
        // init: false,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        breakpoints: {
          1024: {
            slidesPerView: 3,
            spaceBetween: 40
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 30
          },
          640: {
            slidesPerView: 1,
            spaceBetween: 20
          }
        }
      }
    };
  },
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/dist/css/swiper.min.css */ "./node_modules/swiper/dist/css/swiper.min.css");
/* harmony import */ var swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_dist_css_swiper_min_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiper"],
    swiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["swiperSlide"]
  },
  data: function data() {
    return {
      swiperOption: {
        slidesPerView: 3,
        centeredSlides: true,
        spaceBetween: 30,
        pagination: {
          el: '.swiper-pagination',
          type: 'fraction'
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        },
        virtual: {
          slides: function () {
            var slides = [];

            for (var i = 0; i < 600; i += 1) {
              slides.push("Slide ".concat(i + 1));
            }

            return slides;
          }()
        },
        breakpoints: {
          1024: {
            slidesPerView: 3,
            spaceBetween: 40
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 30
          },
          640: {
            slidesPerView: 1,
            spaceBetween: 20
          }
        }
      }
    };
  },
  methods: {
    toSlide: function toSlide(i) {
      this.$refs.mySwiper.swiper.slideTo(i, 0);
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "[dir] .swiper-container[data-v-d8c0bc20] {\n  background-color: #000;\n}\n.gallery-top[data-v-d8c0bc20] {\n  height: 80% !important;\n  width: 100%;\n}\n.gallery-thumbs[data-v-d8c0bc20] {\n  height: 20% !important;\n  box-sizing: border-box;\n}\n[dir] .gallery-thumbs[data-v-d8c0bc20] {\n  padding: 10px 0;\n}\n.gallery-thumbs .swiper-slide[data-v-d8c0bc20] {\n  width: 25%;\n  height: 100%;\n  opacity: 0.4;\n}\n.gallery-thumbs .swiper-slide-active[data-v-d8c0bc20] {\n  opacity: 1;\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".swiper-container[data-v-6d18e86b]  .swiper-slide {\n  font-size: 38px;\n  font-weight: 700;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  min-height: 300px;\n}[dir] .swiper-container[data-v-6d18e86b]  .swiper-slide {\n  text-align: center;\n  background-color: #eee;\n}\n[dir] .theme-dark .swiper-container[data-v-6d18e86b]  .swiper-slide {\n  background-color: #242a47;\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".swiper-inner[data-v-0c467e43] {\n  width: 100%;\n  height: 400px;\n}[dir] .swiper-inner[data-v-0c467e43] {\n  padding-top: 50px;\n  padding-bottom: 50px;\n}\n.swiper-slide[data-v-0c467e43] {\n  width: 300px;\n  height: 300px;\n}\n[dir] .swiper-slide[data-v-0c467e43] {\n  background-position: center;\n  background-size: cover;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".swiper-inner[data-v-2a938e98] {\n  position: relative;\n  overflow: hidden;\n  height: 330px;\n}[dir] .swiper-inner[data-v-2a938e98] {\n  padding: 15px;\n}\n.swiper-container[data-v-2a938e98] {\n  width: 300px !important;\n  height: 300px;\n  position: absolute;\n  top: 50%;\n}\n[dir] .swiper-container[data-v-2a938e98] {\n  margin-top: -150px;\n}\n[dir=ltr] .swiper-container[data-v-2a938e98] {\n  left: 50%;\n  margin-left: -150px;\n}\n[dir=rtl] .swiper-container[data-v-2a938e98] {\n  right: 50%;\n  margin-right: -150px;\n}\n[dir] .swiper-slide[data-v-2a938e98] {\n  background-position: center;\n  background-size: cover;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".swiper-slide[data-v-b1ed9074] {\n  font-size: 18px;\n  min-height: 300px;\n}[dir] .swiper-slide[data-v-b1ed9074] {\n  text-align: center;\n  background: #444 !important;\n}\n.swiper-slide img[data-v-b1ed9074] {\n  width: auto;\n  height: auto;\n  max-width: 100%;\n  /*max-height: 100%;*/\n  position: absolute;\n  top: 50%;\n}\n[dir=ltr] .swiper-slide img[data-v-b1ed9074] {\n  transform: translate(-50%, -50%);\n  left: 50%;\n}\n[dir=rtl] .swiper-slide img[data-v-b1ed9074] {\n  transform: translate(50%, -50%);\n  right: 50%;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var escape = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/url/escape.js */ "./node_modules/css-loader/lib/url/escape.js");
exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".swiper-slide[data-v-15c8272e] {\n  font-size: 18px;\n  color: #fff;\n  box-sizing: border-box;\n  justify-content: space-around !important;\n}[dir] .swiper-slide[data-v-15c8272e] {\n  padding: 40px 60px;\n  background-color: transparent !important;\n}\n.parallax-bg[data-v-15c8272e] {\n  position: absolute;\n  top: 0;\n  width: 130%;\n  height: 100%;\n  -webkit-background-size: cover;\n}\n[dir] .parallax-bg[data-v-15c8272e] {\n  background-size: cover;\n  background-position: center;\n  background-image: url(" + escape(__webpack_require__(/*! ../../../../../../assets/images/pages/carousel/banner-4.jpg */ "./resources/assets/images/pages/carousel/banner-4.jpg")) + ");\n}\n[dir=ltr] .parallax-bg[data-v-15c8272e] {\n  left: 0;\n}\n[dir=rtl] .parallax-bg[data-v-15c8272e] {\n  right: 0;\n}\n.swiper-slide .title[data-v-15c8272e] {\n  font-size: 41px;\n  font-weight: 300;\n}\n.swiper-slide .subtitle[data-v-15c8272e] {\n  font-size: 21px;\n}\n.swiper-slide .text[data-v-15c8272e] {\n  font-size: 14px;\n  max-width: 400px;\n  line-height: 1.3;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true& */ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true& */ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader??ref--7-1!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader??ref--7-1!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader??ref--7-1!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--7-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader??ref--7-1!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=template&id=f3716f9c&":
/*!***********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=template&id=f3716f9c& ***!
  \***********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "extra-component-vue-awesome-swiper-demo" } },
    [
      _c("carousel-default"),
      _vm._v(" "),
      _c("carousel-navigation"),
      _vm._v(" "),
      _c("carousel-pagination"),
      _vm._v(" "),
      _c("carousel-progress"),
      _vm._v(" "),
      _c("carousel-multiple-slides-per-view"),
      _vm._v(" "),
      _c("carousel-multi-row-slides-layout"),
      _vm._v(" "),
      _c("carousel-effect-fade"),
      _vm._v(" "),
      _c("carousel-3d-effect"),
      _vm._v(" "),
      _c("carousel-3d-coverflow-effect"),
      _vm._v(" "),
      _c("carousel-autoplay"),
      _vm._v(" "),
      _c("carousel-gallery"),
      _vm._v(" "),
      _c("carousel-parallax"),
      _vm._v(" "),
      _c("carousel-lazy-loading"),
      _vm._v(" "),
      _c("carousel-responsive-breakpoints"),
      _vm._v(" "),
      _c("carousel-virtual-slides")
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=template&id=0c467e43&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=template&id=0c467e43&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "3d Effect Coverflow Effect", "code-toggler": "" }
    },
    [
      _c(
        "div",
        { staticClass: "swiper-inner" },
        [
          _c(
            "swiper",
            {
              key: _vm.$vs.rtl,
              attrs: {
                options: _vm.swiperOption,
                dir: _vm.$vs.rtl ? "rtl" : "ltr"
              }
            },
            [
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-39.jpg */ "./resources/assets/images/pages/carousel/banner-39.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-35.jpg */ "./resources/assets/images/pages/carousel/banner-35.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-37.jpg */ "./resources/assets/images/pages/carousel/banner-37.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-38.jpg */ "./resources/assets/images/pages/carousel/banner-38.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-33.jpg */ "./resources/assets/images/pages/carousel/banner-33.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-40.jpg */ "./resources/assets/images/pages/carousel/banner-40.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-32.jpg */ "./resources/assets/images/pages/carousel/banner-32.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("div", {
                staticClass: "swiper-pagination",
                attrs: { slot: "pagination" },
                slot: "pagination"
              })
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n        <div class="swiper-inner">\n            <!-- swiper -->\n            <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-39.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-35.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-37.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-38.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-33.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-40.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-32.jpg" alt="banner">\n                </swiper-slide>\n                <div class="swiper-pagination" slot="pagination"></div>\n            </swiper>\n        </div>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    data() {\n        return {\n            swiperOption: {\n                effect: \'cube\',\n                grabCursor: true,\n                cubeEffect: {\n                    shadow: true,\n                    slideShadows: true,\n                    shadowOffset: 20,\n                    shadowScale: 0.94\n                },\n                pagination: {\n                    el: \'.swiper-pagination\'\n                }\n            }\n        }\n    },\n    components: {\n        swiper,\n        swiperSlide\n    }\n}\n</script>\n\n<style scoped>\n.swiper-inner {\n    position: relative;\n    overflow: hidden;\n    height: 330px;\n    padding: 15px;\n}\n\n.swiper-container {\n    width: 300px !important;\n    height: 300px;\n    position: absolute;\n    left: 50%;\n    top: 50%;\n    margin-left: -150px;\n    margin-top: -150px;\n}\n\n.swiper-slide {\n    background-position: center;\n    background-size: cover;\n}\n</style>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=template&id=2a938e98&scoped=true&":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=template&id=2a938e98&scoped=true& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "3d Effect", "code-toggler": "" }
    },
    [
      _c(
        "div",
        { staticClass: "swiper-inner" },
        [
          _c(
            "swiper",
            {
              key: _vm.$vs.rtl,
              attrs: {
                options: _vm.swiperOption,
                dir: _vm.$vs.rtl ? "rtl" : "ltr"
              }
            },
            [
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-21.jpg */ "./resources/assets/images/pages/carousel/banner-21.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-23.jpg */ "./resources/assets/images/pages/carousel/banner-23.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-27.jpg */ "./resources/assets/images/pages/carousel/banner-27.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-29.jpg */ "./resources/assets/images/pages/carousel/banner-29.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-30.jpg */ "./resources/assets/images/pages/carousel/banner-30.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-37.jpg */ "./resources/assets/images/pages/carousel/banner-37.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-39.jpg */ "./resources/assets/images/pages/carousel/banner-39.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("div", {
                staticClass: "swiper-pagination",
                attrs: { slot: "pagination" },
                slot: "pagination"
              })
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n        <div class="swiper-inner">\n            <!-- swiper -->\n            <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-21.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-23.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-27.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-29.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-30.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-37.jpg" alt="banner">\n                </swiper-slide>\n                <swiper-slide>\n                  <img class="responsive" src="@assets/images/pages/carousel/banner-39.jpg" alt="banner">\n                </swiper-slide>\n                <div class="swiper-pagination" slot="pagination"></div>\n            </swiper>\n        </div>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    data() {\n        return {\n            swiperOption: {\n                effect: \'cube\',\n                grabCursor: true,\n                cubeEffect: {\n                    shadow: true,\n                    slideShadows: true,\n                    shadowOffset: 20,\n                    shadowScale: 0.94\n                },\n                pagination: {\n                    el: \'.swiper-pagination\'\n                }\n            }\n        }\n    },\n    components: {\n        swiper,\n        swiperSlide\n    }\n}\n</script>\n\n<style scoped>\n.swiper-inner {\n    position: relative;\n    overflow: hidden;\n    height: 330px;\n    padding: 15px;\n}\n\n.swiper-container {\n    width: 300px !important;\n    height: 300px;\n    position: absolute;\n    left: 50%;\n    top: 50%;\n    margin-left: -150px;\n    margin-top: -150px;\n}\n\n.swiper-slide {\n    background-position: center;\n    background-size: cover;\n}\n</style>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=template&id=71161b96&":
/*!*******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=template&id=71161b96& ***!
  \*******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Autoplay", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-16.jpg */ "./resources/assets/images/pages/carousel/banner-16.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-13.jpg */ "./resources/assets/images/pages/carousel/banner-13.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-4.jpg */ "./resources/assets/images/pages/carousel/banner-4.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-2.jpg */ "./resources/assets/images/pages/carousel/banner-2.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev swiper-button-white",
            attrs: { slot: "button-prev" },
            slot: "button-prev"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next swiper-button-white",
            attrs: { slot: "button-next" },
            slot: "button-next"
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n        <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-16.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-13.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-4.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-2.jpg" alt="banner">\n            </swiper-slide>\n            <div class="swiper-pagination" slot="pagination"></div>\n            <div class="swiper-button-prev" slot="button-prev"></div>\n            <div class="swiper-button-next" slot="button-next"></div>\n        </swiper>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    data() {\n        return {\n            swiperOption: {\n                spaceBetween: 30,\n                centeredSlides: true,\n                autoplay: {\n                    delay: 2500,\n                    disableOnInteraction: false\n                },\n                pagination: {\n                    el: \'.swiper-pagination\',\n                    clickable: true\n                },\n                navigation: {\n                    nextEl: \'.swiper-button-next\',\n                    prevEl: \'.swiper-button-prev\'\n                }\n            }\n        },\n        components: {\n            swiper,\n            swiperSlide\n        }\n    }\n</script>\n          '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=template&id=0ca01d42&":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=template&id=0ca01d42& ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Default", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        { key: _vm.$vs.rtl, attrs: { dir: _vm.$vs.rtl ? "rtl" : "ltr" } },
        [
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-18.jpg */ "./resources/assets/images/pages/carousel/banner-18.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-15.jpg */ "./resources/assets/images/pages/carousel/banner-15.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-10.jpg */ "./resources/assets/images/pages/carousel/banner-10.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-16.jpg */ "./resources/assets/images/pages/carousel/banner-16.jpg"),
                alt: "banner"
              }
            })
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n          <swiper :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-18.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-15.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-10.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-16.jpg" alt="banner">\n            </swiper-slide>\n          </swiper>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    components: {\n        swiper,\n        swiperSlide\n    }\n}\n</script>\n          '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=template&id=8b62de02&":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=template&id=8b62de02& ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Fade Effect", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-16.jpg */ "./resources/assets/images/pages/carousel/banner-16.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-10.jpg */ "./resources/assets/images/pages/carousel/banner-10.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-15.jpg */ "./resources/assets/images/pages/carousel/banner-15.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-18.jpg */ "./resources/assets/images/pages/carousel/banner-18.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination swiper-pagination-white",
            attrs: { slot: "pagination" },
            slot: "pagination"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev swiper-button-white",
            attrs: { slot: "button-prev" },
            slot: "button-prev"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next swiper-button-white",
            attrs: { slot: "button-next" },
            slot: "button-next"
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n    <swiper-slide>\n      <img class="responsive" src="@assets/images/pages/carousel/banner-18.jpg" alt="banner">\n    </swiper-slide>\n    <swiper-slide>\n      <img class="responsive" src="@assets/images/pages/carousel/banner-15.jpg" alt="banner">\n    </swiper-slide>\n    <swiper-slide>\n      <img class="responsive" src="@assets/images/pages/carousel/banner-10.jpg" alt="banner">\n    </swiper-slide>\n    <swiper-slide>\n      <img class="responsive" src="@assets/images/pages/carousel/banner-16.jpg" alt="banner">\n    </swiper-slide>\n    <div class="swiper-pagination swiper-pagination-white" slot="pagination"></div>\n    <div class="swiper-button-prev swiper-button-white" slot="button-prev"></div>\n    <div class="swiper-button-next swiper-button-white" slot="button-next"></div>\n  </swiper>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n  data() {\n    return {\n      swiperOption: {\n        spaceBetween: 30,\n        effect: \'fade\',\n        pagination: {\n            el: \'.swiper-pagination\',\n            clickable: true\n        },\n        navigation: {\n            nextEl: \'.swiper-button-next\',\n            prevEl: \'.swiper-button-prev\'\n        }\n      }\n    }\n  },\n  components: {\n    swiper,\n    swiperSlide\n  }\n}\n</script>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=template&id=d8c0bc20&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=template&id=d8c0bc20&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example-gallery",
      attrs: { title: "Gallery", "code-toggler": "" }
    },
    [
      _c(
        "div",
        [
          _c(
            "swiper",
            {
              key: _vm.$vs.rtl + " gallery",
              ref: "swiperTop",
              staticClass: "gallery-top",
              attrs: {
                options: _vm.swiperOptionTop,
                dir: _vm.$vs.rtl ? "rtl" : "ltr"
              }
            },
            [
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-10.jpg */ "./resources/assets/images/pages/carousel/banner-10.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-16.jpg */ "./resources/assets/images/pages/carousel/banner-16.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-15.jpg */ "./resources/assets/images/pages/carousel/banner-15.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-13.jpg */ "./resources/assets/images/pages/carousel/banner-13.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("div", {
                staticClass: "swiper-button-next swiper-button-white",
                attrs: { slot: "button-next" },
                slot: "button-next"
              }),
              _vm._v(" "),
              _c("div", {
                staticClass: "swiper-button-prev swiper-button-white",
                attrs: { slot: "button-prev" },
                slot: "button-prev"
              })
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "swiper",
            {
              key: _vm.$vs.rtl + " thumbs",
              ref: "swiperThumbs",
              staticClass: "gallery-thumbs",
              attrs: {
                options: _vm.swiperOptionThumbs,
                dir: _vm.$vs.rtl ? "rtl gallery" : "ltr gallery"
              }
            },
            [
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-10.jpg */ "./resources/assets/images/pages/carousel/banner-10.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-16.jpg */ "./resources/assets/images/pages/carousel/banner-16.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-15.jpg */ "./resources/assets/images/pages/carousel/banner-15.jpg"),
                    alt: "banner"
                  }
                })
              ]),
              _vm._v(" "),
              _c("swiper-slide", [
                _c("img", {
                  staticClass: "responsive",
                  attrs: {
                    src: __webpack_require__(/*! @assets/images/pages/carousel/banner-13.jpg */ "./resources/assets/images/pages/carousel/banner-13.jpg"),
                    alt: "banner"
                  }
                })
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <div style="height: 500px">\n\n    <!-- swiper1 -->\n        <swiper :options="swiperOptionTop" class="gallery-top" ref="swiperTop" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-10.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-16.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-15.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-13.jpg" alt="banner">\n            </swiper-slide>\n            <div class="swiper-button-next swiper-button-white" slot="button-next"></div>\n            <div class="swiper-button-prev swiper-button-white" slot="button-prev"></div>\n        </swiper>\n\n        <!-- swiper2 Thumbs -->\n        <swiper :options="swiperOptionThumbs" class="gallery-thumbs" ref="swiperThumbs" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-10.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-16.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-15.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-13.jpg" alt="banner">\n            </swiper-slide>\n        </swiper>\n  </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n  data() {\n    return {\n      swiperOptionTop: {\n        spaceBetween: 10,\n        navigation: {\n          nextEl: \'.swiper-button-next\',\n          prevEl: \'.swiper-button-prev\'\n        }\n      },\n      swiperOptionThumbs: {\n        spaceBetween: 10,\n        centeredSlides: true,\n        slidesPerView: \'auto\',\n        touchRatio: 0.2,\n        slideToClickedSlide: true\n      }\n    }\n  },\n  mounted() {\n    this.$nextTick(() => {\n      const swiperTop = this.$refs.swiperTop.swiper\n      const swiperThumbs = this.$refs.swiperThumbs.swiper\n      swiperTop.controller.control = swiperThumbs\n      swiperThumbs.controller.control = swiperTop\n    })\n  },\n  components: {\n    swiper,\n    swiperSlide\n  }\n}\n</script>\n\n\n<style lang="scss" scoped>\n  .swiper-container {\n    background-color: #000;\n  }\n  .gallery-top {\n    height: 80%!important;\n    width: 100%;\n  }\n  .gallery-thumbs {\n    height: 20%!important;\n    box-sizing: border-box;\n    padding: 10px 0;\n  }\n  .gallery-thumbs .swiper-slide {\n    width: 25%;\n    height: 100%;\n    opacity: 0.4;\n  }\n  .gallery-thumbs .swiper-slide-active {\n    opacity: 1;\n  }\n</style>\n          '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=template&id=b1ed9074&scoped=true&":
/*!**********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=template&id=b1ed9074&scoped=true& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Lazy Loading", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _vm._l(_vm.slides, function(slide) {
            return _c("swiper-slide", { key: slide.img }, [
              _c("img", {
                staticClass: "swiper-lazy",
                attrs: { "data-src": slide.img }
              }),
              _vm._v(" "),
              _c("div", {
                staticClass: "swiper-lazy-preloader swiper-lazy-preloader-white"
              })
            ])
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next swiper-button-white",
            attrs: { slot: "button-next" },
            slot: "button-next"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev swiper-button-white",
            attrs: { slot: "button-prev" },
            slot: "button-prev"
          })
        ],
        2
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <!-- swiper -->\n    <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n\n        <swiper-slide v-for="slide in slides" :key="slide.img">\n            <img :data-src="slide.img" class="swiper-lazy">\n            <div class="swiper-lazy-preloader swiper-lazy-preloader-white"></div>\n        </swiper-slide>\n\n        <div class="swiper-pagination" slot="pagination"></div>\n        <div class="swiper-button-next swiper-button-white" slot="button-next"></div>\n        <div class="swiper-button-prev swiper-button-white" slot="button-prev"></div>\n    </swiper>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    data() {\n        return {\n            swiperOption: {\n                // Enable lazy loading\n                lazy: true,\n                pagination: {\n                    el: \'.swiper-pagination\',\n                    clickable: true\n                },\n                navigation: {\n                    nextEl: \'.swiper-button-next\',\n                    prevEl: \'.swiper-button-prev\'\n                }\n            },\n            slides: [\n              { img: require(\'@assets/images/pages/carousel/banner-13.jpg\') },\n              { img: require(\'@assets/images/pages/carousel/banner-7.jpg\')  },\n              { img: require(\'@assets/images/pages/carousel/banner-10.jpg\') },\n              { img: require(\'@assets/images/pages/carousel/banner-16.jpg\') },\n              { img: require(\'@assets/images/pages/carousel/banner-20.jpg\') },\n            ]\n        }\n    },\n  components: {\n    swiper,\n    swiperSlide\n  }\n}\n</script>\n\n<style scoped>\n.swiper-slide {\n  text-align: center;\n  font-size: 18px;\n  background: #444 !important;\n}\n\n.swiper-slide img {\n  width: auto;\n  height: auto;\n  max-width: 100%;\n  /*max-height: 100%;*/\n  -ms-transform: translate(-50%, -50%);\n  -webkit-transform: translate(-50%, -50%);\n  -moz-transform: translate(-50%, -50%);\n  transform: translate(-50%, -50%);\n  position: absolute;\n  left: 50%;\n  top: 50%;\n}\n</style>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=template&id=4112abff&":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=template&id=4112abff& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Multi Row Slides Layout", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-31.jpg */ "./resources/assets/images/pages/carousel/banner-31.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-32.jpg */ "./resources/assets/images/pages/carousel/banner-32.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-33.jpg */ "./resources/assets/images/pages/carousel/banner-33.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-34.jpg */ "./resources/assets/images/pages/carousel/banner-34.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-35.jpg */ "./resources/assets/images/pages/carousel/banner-35.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-23.jpg */ "./resources/assets/images/pages/carousel/banner-23.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-37.jpg */ "./resources/assets/images/pages/carousel/banner-37.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-38.jpg */ "./resources/assets/images/pages/carousel/banner-38.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-39.jpg */ "./resources/assets/images/pages/carousel/banner-39.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-40.jpg */ "./resources/assets/images/pages/carousel/banner-40.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination"
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n        <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-31.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-32.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-33.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-34.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-35.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-23.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-37.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-38.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-39.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-40.jpg" alt="banner">\n            </swiper-slide>\n            <div class="swiper-pagination" slot="pagination"></div>\n        </swiper>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    data() {\n        return {\n            swiperOption: {\n                slidesPerView: 3,\n                slidesPerColumn: 2,\n                spaceBetween: 30,\n                pagination: {\n                    el: \'.swiper-pagination\',\n                    clickable: true\n                },\n                breakpoints: {\n                    1024: {\n                        slidesPerView: 3,\n                        spaceBetween: 40\n                    },\n                    768: {\n                        slidesPerView: 2,\n                        spaceBetween: 30\n                    },\n                    640: {\n                        slidesPerView: 1,\n                        spaceBetween: 20\n                    }\n                }\n            }\n        }\n    },\n    components: {\n        swiper,\n        swiperSlide\n    }\n}\n</script>\n\n<style lang="scss">\n.carousel-example .swiper-container .swiper-slide {\n    text-align: center;\n    font-size: 38px;\n    font-weight: 700;\n    background-color: #eee;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: center;\n    -ms-flex-pack: center;\n    justify-content: center;\n    -webkit-box-align: center;\n    -ms-flex-align: center;\n    align-items: center;\n    min-height: 300px;\n}\n</style>\n          '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=template&id=2c55930e&":
/*!********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=template&id=2c55930e& ***!
  \********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Multiple Slides Per View", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-21.jpg */ "./resources/assets/images/pages/carousel/banner-21.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-22.jpg */ "./resources/assets/images/pages/carousel/banner-22.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-23.jpg */ "./resources/assets/images/pages/carousel/banner-23.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-29.jpg */ "./resources/assets/images/pages/carousel/banner-29.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-30.jpg */ "./resources/assets/images/pages/carousel/banner-30.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination"
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n        <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-21.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-22.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-23.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-29.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-30.jpg" alt="banner">\n            </swiper-slide>\n            <div class="swiper-pagination" slot="pagination"></div>\n        </swiper>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    data() {\n        return {\n            swiperOption: {\n                slidesPerView: 3,\n                spaceBetween: 30,\n                pagination: {\n                    el: \'.swiper-pagination\',\n                    clickable: true\n                },\n                breakpoints: {\n                    1024: {\n                        slidesPerView: 3,\n                        spaceBetween: 40\n                    },\n                    768: {\n                        slidesPerView: 2,\n                        spaceBetween: 30\n                    },\n                    640: {\n                        slidesPerView: 1,\n                        spaceBetween: 20\n                    }\n                }\n            }\n        }\n    },\n    components: {\n        swiper,\n        swiperSlide\n    }\n}\n</script>\n\n          '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=template&id=06363be6&":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=template&id=06363be6& ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Navigations", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-13.jpg */ "./resources/assets/images/pages/carousel/banner-13.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-7.jpg */ "./resources/assets/images/pages/carousel/banner-7.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-11.jpg */ "./resources/assets/images/pages/carousel/banner-11.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-1.jpg */ "./resources/assets/images/pages/carousel/banner-1.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev swiper-button-white",
            attrs: { slot: "button-prev" },
            slot: "button-prev"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next swiper-button-white",
            attrs: { slot: "button-next" },
            slot: "button-next"
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n        <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-13.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-7.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-11.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-1.jpg" alt="banner">\n            </swiper-slide>\n            <div class="swiper-button-prev" slot="button-prev"></div>\n            <div class="swiper-button-next" slot="button-next"></div>\n        </swiper>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default{\n  data() {\n    return {\n        swiperOption: {\n            navigation: {\n              nextEl: \'.swiper-button-next\',\n              prevEl: \'.swiper-button-prev\'\n            }\n          }\n    }\n  },\n  components: {\n    swiper,\n    swiperSlide\n  }\n}\n</script>\n          '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=template&id=048b366c&":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=template&id=048b366c& ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Pagination", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-16.jpg */ "./resources/assets/images/pages/carousel/banner-16.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-19.jpg */ "./resources/assets/images/pages/carousel/banner-19.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-5.jpg */ "./resources/assets/images/pages/carousel/banner-5.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-9.jpg */ "./resources/assets/images/pages/carousel/banner-9.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination"
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n        <swiper :options="swiperOption">\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-16.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-19.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-5.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-9.jpg" alt="banner">\n            </swiper-slide>\n            <div class="swiper-pagination" slot="pagination"></div>\n        </swiper>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    data() {\n        return {\n            swiperOption: {\n                pagination: {\n                    el: \'.swiper-pagination\'\n                }\n            }\n        }\n    },\n    components: {\n        swiper,\n        swiperSlide\n    }\n}\n</script>\n          '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=template&id=15c8272e&scoped=true&":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=template&id=15c8272e&scoped=true& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Parallax", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _c("div", {
            staticClass: "parallax-bg",
            attrs: { slot: "parallax-bg", "data-swiper-parallax": "-23%" },
            slot: "parallax-bg"
          }),
          _vm._v(" "),
          _c("swiper-slide", [
            _c(
              "div",
              {
                staticClass: "title",
                attrs: { "data-swiper-parallax": "-100" }
              },
              [_vm._v("Slide 1")]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "subtitle font-semibold",
                attrs: { "data-swiper-parallax": "-200" }
              },
              [_vm._v("Subtitle")]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "text",
                attrs: { "data-swiper-parallax": "-300" }
              },
              [
                _c("p", { staticClass: "font-medium" }, [
                  _vm._v(
                    "Jelly chocolate cupcake chocolate bar caramels chupa chups chupa chups ice cream tiramisu. Oat cake muffin pastry marzipan sweet jujubes powder cupcake carrot cake. Caramels candy pastry marzipan pudding. Sugar plum carrot cake topping cookie."
                  )
                ])
              ]
            )
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c(
              "div",
              {
                staticClass: "title",
                attrs: { "data-swiper-parallax": "-100" }
              },
              [_vm._v("Slide 2")]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "subtitle font-semibold",
                attrs: { "data-swiper-parallax": "-200" }
              },
              [_vm._v("Subtitle")]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "text",
                attrs: { "data-swiper-parallax": "-300" }
              },
              [
                _c("p", { staticClass: "font-medium" }, [
                  _vm._v(
                    "Sweet oat cake marzipan jelly brownie ice cream bear claw marshmallow jelly beans. Halvah dessert caramels toffee sweet cake tiramisu. Chocolate bar marshmallow topping biscuit gummies chocolate cake candy liquorice."
                  )
                ])
              ]
            )
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c(
              "div",
              {
                staticClass: "title",
                attrs: { "data-swiper-parallax": "-100" }
              },
              [_vm._v("Slide 3")]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "subtitle font-semibold",
                attrs: { "data-swiper-parallax": "-200" }
              },
              [_vm._v("Subtitle")]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "text",
                attrs: { "data-swiper-parallax": "-300" }
              },
              [
                _c("p", { staticClass: "font-medium" }, [
                  _vm._v(
                    "Powder jelly bonbon liquorice candy canes jujubes fruitcake cotton candy macaroon. Croissant jelly-o tootsie roll halvah. Topping lollipop pastry. Fruitcake powder cupcake apple pie chocolate bar wafer. brownie macaroon dragée chocolate bar candy."
                  )
                ])
              ]
            )
          ]),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination swiper-pagination-white",
            attrs: { slot: "pagination" },
            slot: "pagination"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev swiper-button-white",
            attrs: { slot: "button-prev" },
            slot: "button-prev"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next swiper-button-white",
            attrs: { slot: "button-next" },
            slot: "button-next"
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n        <!-- swiper -->\n        <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <div class="parallax-bg" slot="parallax-bg" data-swiper-parallax="-23%"></div>\n            <swiper-slide>\n                <div class="title" data-swiper-parallax="-100">Slide 1</div>\n                <div class="subtitle font-semibold" data-swiper-parallax="-200">Subtitle</div>\n                <div class="text" data-swiper-parallax="-300">\n                    <p class="font-medium">Jelly chocolate cupcake chocolate bar caramels chupa chups chupa chups ice cream tiramisu. Oat cake muffin pastry marzipan sweet jujubes powder cupcake carrot cake. Caramels candy pastry marzipan pudding. Sugar plum carrot cake topping cookie.</p>\n                </div>\n            </swiper-slide>\n            <swiper-slide>\n                <div class="title" data-swiper-parallax="-100">Slide 2</div>\n                <div class="subtitle font-semibold" data-swiper-parallax="-200">Subtitle</div>\n                <div class="text" data-swiper-parallax="-300">\n                    <p class="font-medium">Sweet oat cake marzipan jelly brownie ice cream bear claw marshmallow jelly beans. Halvah dessert caramels toffee sweet cake tiramisu. Chocolate bar marshmallow topping biscuit gummies chocolate cake candy liquorice.</p>\n                </div>\n            </swiper-slide>\n            <swiper-slide>\n                <div class="title" data-swiper-parallax="-100">Slide 3</div>\n                <div class="subtitle font-semibold" data-swiper-parallax="-200">Subtitle</div>\n                <div class="text" data-swiper-parallax="-300">\n                    <p class="font-medium">Powder jelly bonbon liquorice candy canes jujubes fruitcake cotton candy macaroon. Croissant jelly-o tootsie roll halvah. Topping lollipop pastry. Fruitcake powder cupcake apple pie chocolate bar wafer. brownie macaroon dragée chocolate bar candy.</p>\n                </div>\n            </swiper-slide>\n            <div class="swiper-pagination swiper-pagination-white" slot="pagination"></div>\n            <div class="swiper-button-prev swiper-button-white" slot="button-prev"></div>\n            <div class="swiper-button-next swiper-button-white" slot="button-next"></div>\n        </swiper>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    data() {\n        return {\n            swiperOption: {\n                speed: 600,\n                parallax: true,\n                pagination: {\n                    el: \'.swiper-pagination\',\n                    clickable: true\n                },\n                navigation: {\n                    nextEl: \'.swiper-button-next\',\n                    prevEl: \'.swiper-button-prev\'\n                }\n            }\n        }\n    },\n    components: {\n        swiper,\n        swiperSlide\n    }\n}\n</script>\n\n<style scoped>\n.swiper-slide {\n    font-size: 18px;\n    color: #fff;\n    -webkit-box-sizing: border-box;\n    box-sizing: border-box;\n    padding: 40px 60px;\n    background-color: transparent !important;\n    justify-content: space-around !important;\n}\n\n.parallax-bg {\n    position: absolute;\n    left: 0;\n    top: 0;\n    width: 130%;\n    height: 100%;\n    -webkit-background-size: cover;\n    background-size: cover;\n    background-position: center;\n    background-image: url(\'../../../../../../assets/images/slider/04.jpg\')\n}\n\n.swiper-slide .title {\n    font-size: 41px;\n    font-weight: 300;\n}\n\n.swiper-slide .subtitle {\n    font-size: 21px;\n}\n\n.swiper-slide .text {\n    font-size: 14px;\n    max-width: 400px;\n    line-height: 1.3;\n}\n</style>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=template&id=df137402&":
/*!*******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=template&id=df137402& ***!
  \*******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Progress", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-10.jpg */ "./resources/assets/images/pages/carousel/banner-10.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-7.jpg */ "./resources/assets/images/pages/carousel/banner-7.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-9.jpg */ "./resources/assets/images/pages/carousel/banner-9.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-11.jpg */ "./resources/assets/images/pages/carousel/banner-11.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev swiper-button-white",
            attrs: { slot: "button-prev" },
            slot: "button-prev"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next swiper-button-white",
            attrs: { slot: "button-next" },
            slot: "button-next"
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n        <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-10.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-7.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-9.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-11.jpg" alt="banner">\n            </swiper-slide>\n            <div class="swiper-pagination" slot="pagination"></div>\n            <div class="swiper-button-prev" slot="button-prev"></div>\n            <div class="swiper-button-next" slot="button-next"></div>\n        </swiper>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    data() {\n        return {\n            swiperOption: {\n                pagination: {\n                    el: \'.swiper-pagination\',\n                    type: \'progressbar\'\n                },\n                navigation: {\n                    nextEl: \'.swiper-button-next\',\n                    prevEl: \'.swiper-button-prev\'\n                }\n            }\n        }\n    },\n    components: {\n        swiper,\n        swiperSlide\n    }\n}\n</script>\n          '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=template&id=66366e6c&":
/*!********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=template&id=66366e6c& ***!
  \********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Responsive Breakpoints", "code-toggler": "" }
    },
    [
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-31.jpg */ "./resources/assets/images/pages/carousel/banner-31.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-32.jpg */ "./resources/assets/images/pages/carousel/banner-32.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-33.jpg */ "./resources/assets/images/pages/carousel/banner-33.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-29.jpg */ "./resources/assets/images/pages/carousel/banner-29.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-35.jpg */ "./resources/assets/images/pages/carousel/banner-35.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-23.jpg */ "./resources/assets/images/pages/carousel/banner-23.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-37.jpg */ "./resources/assets/images/pages/carousel/banner-37.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-38.jpg */ "./resources/assets/images/pages/carousel/banner-38.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-39.jpg */ "./resources/assets/images/pages/carousel/banner-39.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("swiper-slide", [
            _c("img", {
              staticClass: "responsive",
              attrs: {
                src: __webpack_require__(/*! @assets/images/pages/carousel/banner-40.jpg */ "./resources/assets/images/pages/carousel/banner-40.jpg"),
                alt: "banner"
              }
            })
          ]),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination"
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n        <!-- swiper -->\n        <swiper :options="swiperOption" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-31.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-32.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-33.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-29.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-35.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-23.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-37.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-38.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-39.jpg" alt="banner">\n            </swiper-slide>\n            <swiper-slide>\n              <img class="responsive" src="@assets/images/pages/carousel/banner-40.jpg" alt="banner">\n            </swiper-slide>\n            <div class="swiper-pagination" slot="pagination"></div>\n        </swiper>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default {\n    data() {\n        return {\n            swiperOption: {\n                slidesPerView: 5,\n                spaceBetween: 50,\n                // init: false,\n                pagination: {\n                    el: \'.swiper-pagination\',\n                    clickable: true\n                },\n                breakpoints: {\n                    1024: {\n                        slidesPerView: 3,\n                        spaceBetween: 40\n                    },\n                    768: {\n                        slidesPerView: 2,\n                        spaceBetween: 30\n                    },\n                    640: {\n                        slidesPerView: 1,\n                        spaceBetween: 20\n                    }\n                }\n            }\n        }\n    },\n    components: {\n        swiper,\n        swiperSlide\n    }\n}\n</script>\n          '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=template&id=6d18e86b&scoped=true&":
/*!************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=template&id=6d18e86b&scoped=true& ***!
  \************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      staticClass: "carousel-example",
      attrs: { title: "Virtual Slides", "code-toggler": "" }
    },
    [
      _c(
        "div",
        { staticClass: "mb-4" },
        [
          _c(
            "vs-button",
            {
              staticClass: "mr-4 mb-4",
              nativeOn: {
                click: function($event) {
                  return _vm.toSlide(0)
                }
              }
            },
            [_vm._v("To Slide 1")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              staticClass: "mr-4 mb-4",
              nativeOn: {
                click: function($event) {
                  return _vm.toSlide(249)
                }
              }
            },
            [_vm._v("To Slide 250")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              staticClass: "mr-4 mb-4",
              nativeOn: {
                click: function($event) {
                  return _vm.toSlide(499)
                }
              }
            },
            [_vm._v("To Slide 500")]
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "swiper",
        {
          key: _vm.$vs.rtl,
          ref: "mySwiper",
          attrs: { options: _vm.swiperOption, dir: _vm.$vs.rtl ? "rtl" : "ltr" }
        },
        [
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev",
            attrs: { slot: "button-prev" },
            slot: "button-prev"
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next",
            attrs: { slot: "button-next" },
            slot: "button-next"
          })
        ]
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n    <div class="carousel-example">\n        <div class="mb-base">\n            <vs-button class="mr-4 mb-4" @click.native="toSlide(0)">To Slide 1</vs-button>\n            <vs-button class="mr-4 mb-4" @click.native="toSlide(249)">To Slide 250</vs-button>\n            <vs-button class="mr-4 mb-4" @click.native="toSlide(499)">To Slide 500</vs-button>\n        </div>\n        <!-- swiper -->\n        <swiper :options="swiperOption" ref="mySwiper" :dir="$vs.rtl ? \'rtl\' : \'ltr\'" :key="$vs.rtl">\n            <div class="swiper-pagination" slot="pagination"></div>\n            <div class="swiper-button-prev" slot="button-prev"></div>\n            <div class="swiper-button-next" slot="button-next"></div>\n        </swiper>\n    </div>\n</template>\n\n<script>\nimport \'swiper/dist/css/swiper.min.css\'\nimport { swiper, swiperSlide } from \'vue-awesome-swiper\'\n\nexport default{\n  components: {\n    swiper,\n    swiperSlide\n  },\n  data() {\n      return {\n        swiperOption: {\n          slidesPerView: 3,\n          centeredSlides: true,\n          spaceBetween: 30,\n          pagination: {\n            el: \'.swiper-pagination\',\n            type: \'fraction\'\n          },\n          navigation: {\n            nextEl: \'.swiper-button-next\',\n            prevEl: \'.swiper-button-prev\'\n          },\n          virtual: {\n            slides: (function () {\n              const slides = [];\n              for (let i = 0; i < 600; i += 1) {\n                slides.push(\'Slide \' + (i + 1))\n              }\n              return slides\n            }())\n          },\n          breakpoints: {\n            1024: {\n              slidesPerView: 3,\n              spaceBetween: 40\n              },\n            768: {\n              slidesPerView: 2,\n              spaceBetween: 30\n              },\n            640: {\n              slidesPerView: 1,\n              spaceBetween: 20\n              }\n          }\n        }\n      }\n    },\n    methods: {\n      toSlide(i) {\n        this.$refs.mySwiper.swiper.slideTo(i, 0)\n      }\n    }\n}\n</script>\n\n<style lang="scss" scoped>\n.swiper-container {\n    ::v-deep .swiper-slide {\n        text-align: center;\n        font-size: 38px;\n        font-weight: 700;\n        background-color: #eee;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-pack: center;\n        -ms-flex-pack: center;\n        justify-content: center;\n        -webkit-box-align: center;\n        -ms-flex-align: center;\n        align-items: center;\n        min-height: 300px;\n\n        .theme-dark & {\n          background-color: #242a47;\n        }\n  }\n}\n</style>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-1.jpg":
/*!*************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-1.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-1.jpg?360c88544c8e592dd06f9c3a06619fc9";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-10.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-10.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-10.jpg?fb88ea4fc1468049dd947893d8e85df0";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-11.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-11.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-11.jpg?6f4a134a40da74feae7c47672b90f916";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-13.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-13.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-13.jpg?04939c53cf03053710410aae330a20dd";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-15.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-15.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-15.jpg?402f90acbcac3a73ef58183af2b1d644";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-16.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-16.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-16.jpg?494b2830711b92086bda4ef504fbe2cb";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-18.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-18.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-18.jpg?fed32d927b68adf901c72a1965c7f9a5";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-19.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-19.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-19.jpg?a633b7c96e32e22b3a2c023d00a91494";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-2.jpg":
/*!*************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-2.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-2.jpg?4177aa4225d0496574b3ae3cab2e58a0";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-20.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-20.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-20.jpg?4916d89ae769cad2f3955089bd35c269";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-21.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-21.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-21.jpg?c2fc76f66f94575da60e0c42ed3a46ec";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-22.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-22.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-22.jpg?6d7c72744ac055df82a0a0501dd4ce1d";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-23.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-23.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-23.jpg?a1cc4c357dd9ec800c0e585a1acf43cc";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-27.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-27.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-27.jpg?7076d3ddb1ff0caae9dc2a883b58b89c";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-29.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-29.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-29.jpg?fbd25d2f9220188bde13690468250a4d";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-30.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-30.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-30.jpg?a9c9f8267ab78b7da0a514f3a5495b21";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-31.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-31.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-31.jpg?3650843bb01f6d681cdfde18ce92118c";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-32.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-32.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-32.jpg?6a935d9ec99af1d8919daefbdb596637";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-33.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-33.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-33.jpg?175a6d83cce8590c75e2cf7076012e8d";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-34.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-34.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-34.jpg?096d1a93d7d78d6128884231456a1e6c";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-35.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-35.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-35.jpg?5d7e9c3ee9103c392c270d1cc0ce0006";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-37.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-37.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-37.jpg?e450701c2e4dd200be0d4ee16d0ddb89";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-38.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-38.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-38.jpg?f836f8b37f031e8d036e454a0a339941";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-39.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-39.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-39.jpg?ba77e8e48ff4f8cb223730128815abee";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-4.jpg":
/*!*************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-4.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-4.jpg?385cda2253c959636b31240ddc5bec4d";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-40.jpg":
/*!**************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-40.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-40.jpg?1121dfb87c6ec3749cd98ace9afaa053";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-5.jpg":
/*!*************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-5.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-5.jpg?84f62d8cfd2c6bf4cc8e62ca5fedea44";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-7.jpg":
/*!*************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-7.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-7.jpg?329388dfca05a9662bb88f2582da9355";

/***/ }),

/***/ "./resources/assets/images/pages/carousel/banner-9.jpg":
/*!*************************************************************!*\
  !*** ./resources/assets/images/pages/carousel/banner-9.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/banner-9.jpg?ae669d39a9a7eadaa05d68a14b2b61d0";

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel.vue":
/*!**********************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel.vue ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Carousel_vue_vue_type_template_id_f3716f9c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Carousel.vue?vue&type=template&id=f3716f9c& */ "./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=template&id=f3716f9c&");
/* harmony import */ var _Carousel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Carousel.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Carousel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Carousel_vue_vue_type_template_id_f3716f9c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Carousel_vue_vue_type_template_id_f3716f9c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/Carousel.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Carousel.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=template&id=f3716f9c&":
/*!*****************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=template&id=f3716f9c& ***!
  \*****************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel_vue_vue_type_template_id_f3716f9c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Carousel.vue?vue&type=template&id=f3716f9c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel.vue?vue&type=template&id=f3716f9c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel_vue_vue_type_template_id_f3716f9c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel_vue_vue_type_template_id_f3716f9c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Carousel3dCoverflowEffect_vue_vue_type_template_id_0c467e43_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Carousel3dCoverflowEffect.vue?vue&type=template&id=0c467e43&scoped=true& */ "./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=template&id=0c467e43&scoped=true&");
/* harmony import */ var _Carousel3dCoverflowEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Carousel3dCoverflowEffect.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Carousel3dCoverflowEffect_vue_vue_type_style_index_0_id_0c467e43_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css& */ "./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Carousel3dCoverflowEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Carousel3dCoverflowEffect_vue_vue_type_template_id_0c467e43_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Carousel3dCoverflowEffect_vue_vue_type_template_id_0c467e43_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "0c467e43",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Carousel3dCoverflowEffect.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css&":
/*!************************************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css& ***!
  \************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_style_index_0_id_0c467e43_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader??ref--7-1!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=style&index=0&id=0c467e43&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_style_index_0_id_0c467e43_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_style_index_0_id_0c467e43_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_style_index_0_id_0c467e43_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_style_index_0_id_0c467e43_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_style_index_0_id_0c467e43_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=template&id=0c467e43&scoped=true&":
/*!**********************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=template&id=0c467e43&scoped=true& ***!
  \**********************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_template_id_0c467e43_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Carousel3dCoverflowEffect.vue?vue&type=template&id=0c467e43&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dCoverflowEffect.vue?vue&type=template&id=0c467e43&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_template_id_0c467e43_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dCoverflowEffect_vue_vue_type_template_id_0c467e43_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Carousel3dEffect_vue_vue_type_template_id_2a938e98_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Carousel3dEffect.vue?vue&type=template&id=2a938e98&scoped=true& */ "./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=template&id=2a938e98&scoped=true&");
/* harmony import */ var _Carousel3dEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Carousel3dEffect.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Carousel3dEffect_vue_vue_type_style_index_0_id_2a938e98_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css& */ "./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Carousel3dEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Carousel3dEffect_vue_vue_type_template_id_2a938e98_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Carousel3dEffect_vue_vue_type_template_id_2a938e98_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "2a938e98",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Carousel3dEffect.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css&":
/*!***************************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css& ***!
  \***************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_style_index_0_id_2a938e98_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader??ref--7-1!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=style&index=0&id=2a938e98&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_style_index_0_id_2a938e98_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_style_index_0_id_2a938e98_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_style_index_0_id_2a938e98_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_style_index_0_id_2a938e98_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_style_index_0_id_2a938e98_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=template&id=2a938e98&scoped=true&":
/*!*************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=template&id=2a938e98&scoped=true& ***!
  \*************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_template_id_2a938e98_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Carousel3dEffect.vue?vue&type=template&id=2a938e98&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/Carousel3dEffect.vue?vue&type=template&id=2a938e98&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_template_id_2a938e98_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Carousel3dEffect_vue_vue_type_template_id_2a938e98_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselAutoplay_vue_vue_type_template_id_71161b96___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselAutoplay.vue?vue&type=template&id=71161b96& */ "./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=template&id=71161b96&");
/* harmony import */ var _CarouselAutoplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselAutoplay.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CarouselAutoplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselAutoplay_vue_vue_type_template_id_71161b96___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselAutoplay_vue_vue_type_template_id_71161b96___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselAutoplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselAutoplay.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselAutoplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=template&id=71161b96&":
/*!*************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=template&id=71161b96& ***!
  \*************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselAutoplay_vue_vue_type_template_id_71161b96___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselAutoplay.vue?vue&type=template&id=71161b96& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselAutoplay.vue?vue&type=template&id=71161b96&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselAutoplay_vue_vue_type_template_id_71161b96___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselAutoplay_vue_vue_type_template_id_71161b96___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselDefault_vue_vue_type_template_id_0ca01d42___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselDefault.vue?vue&type=template&id=0ca01d42& */ "./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=template&id=0ca01d42&");
/* harmony import */ var _CarouselDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselDefault.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CarouselDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselDefault_vue_vue_type_template_id_0ca01d42___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselDefault_vue_vue_type_template_id_0ca01d42___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselDefault.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=template&id=0ca01d42&":
/*!************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=template&id=0ca01d42& ***!
  \************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselDefault_vue_vue_type_template_id_0ca01d42___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselDefault.vue?vue&type=template&id=0ca01d42& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselDefault.vue?vue&type=template&id=0ca01d42&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselDefault_vue_vue_type_template_id_0ca01d42___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselDefault_vue_vue_type_template_id_0ca01d42___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselEffectFade_vue_vue_type_template_id_8b62de02___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselEffectFade.vue?vue&type=template&id=8b62de02& */ "./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=template&id=8b62de02&");
/* harmony import */ var _CarouselEffectFade_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselEffectFade.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CarouselEffectFade_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselEffectFade_vue_vue_type_template_id_8b62de02___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselEffectFade_vue_vue_type_template_id_8b62de02___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselEffectFade_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselEffectFade.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselEffectFade_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=template&id=8b62de02&":
/*!***************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=template&id=8b62de02& ***!
  \***************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselEffectFade_vue_vue_type_template_id_8b62de02___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselEffectFade.vue?vue&type=template&id=8b62de02& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselEffectFade.vue?vue&type=template&id=8b62de02&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselEffectFade_vue_vue_type_template_id_8b62de02___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselEffectFade_vue_vue_type_template_id_8b62de02___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselGallery_vue_vue_type_template_id_d8c0bc20_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselGallery.vue?vue&type=template&id=d8c0bc20&scoped=true& */ "./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=template&id=d8c0bc20&scoped=true&");
/* harmony import */ var _CarouselGallery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselGallery.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _CarouselGallery_vue_vue_type_style_index_0_id_d8c0bc20_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true& */ "./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _CarouselGallery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselGallery_vue_vue_type_template_id_d8c0bc20_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselGallery_vue_vue_type_template_id_d8c0bc20_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "d8c0bc20",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselGallery.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true&":
/*!***************************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true& ***!
  \***************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_style_index_0_id_d8c0bc20_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=style&index=0&id=d8c0bc20&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_style_index_0_id_d8c0bc20_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_style_index_0_id_d8c0bc20_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_style_index_0_id_d8c0bc20_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_style_index_0_id_d8c0bc20_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_style_index_0_id_d8c0bc20_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=template&id=d8c0bc20&scoped=true&":
/*!************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=template&id=d8c0bc20&scoped=true& ***!
  \************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_template_id_d8c0bc20_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselGallery.vue?vue&type=template&id=d8c0bc20&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselGallery.vue?vue&type=template&id=d8c0bc20&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_template_id_d8c0bc20_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselGallery_vue_vue_type_template_id_d8c0bc20_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselLazyLoading_vue_vue_type_template_id_b1ed9074_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselLazyLoading.vue?vue&type=template&id=b1ed9074&scoped=true& */ "./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=template&id=b1ed9074&scoped=true&");
/* harmony import */ var _CarouselLazyLoading_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselLazyLoading.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _CarouselLazyLoading_vue_vue_type_style_index_0_id_b1ed9074_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css& */ "./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _CarouselLazyLoading_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselLazyLoading_vue_vue_type_template_id_b1ed9074_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselLazyLoading_vue_vue_type_template_id_b1ed9074_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "b1ed9074",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselLazyLoading.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css&":
/*!******************************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css& ***!
  \******************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_style_index_0_id_b1ed9074_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader??ref--7-1!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=style&index=0&id=b1ed9074&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_style_index_0_id_b1ed9074_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_style_index_0_id_b1ed9074_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_style_index_0_id_b1ed9074_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_style_index_0_id_b1ed9074_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_style_index_0_id_b1ed9074_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=template&id=b1ed9074&scoped=true&":
/*!****************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=template&id=b1ed9074&scoped=true& ***!
  \****************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_template_id_b1ed9074_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselLazyLoading.vue?vue&type=template&id=b1ed9074&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselLazyLoading.vue?vue&type=template&id=b1ed9074&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_template_id_b1ed9074_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselLazyLoading_vue_vue_type_template_id_b1ed9074_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselMultiRowSlidesLayout_vue_vue_type_template_id_4112abff___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselMultiRowSlidesLayout.vue?vue&type=template&id=4112abff& */ "./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=template&id=4112abff&");
/* harmony import */ var _CarouselMultiRowSlidesLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselMultiRowSlidesLayout.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CarouselMultiRowSlidesLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselMultiRowSlidesLayout_vue_vue_type_template_id_4112abff___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselMultiRowSlidesLayout_vue_vue_type_template_id_4112abff___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselMultiRowSlidesLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselMultiRowSlidesLayout.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselMultiRowSlidesLayout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=template&id=4112abff&":
/*!*************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=template&id=4112abff& ***!
  \*************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselMultiRowSlidesLayout_vue_vue_type_template_id_4112abff___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselMultiRowSlidesLayout.vue?vue&type=template&id=4112abff& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselMultiRowSlidesLayout.vue?vue&type=template&id=4112abff&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselMultiRowSlidesLayout_vue_vue_type_template_id_4112abff___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselMultiRowSlidesLayout_vue_vue_type_template_id_4112abff___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselMultipleSlidesPerView_vue_vue_type_template_id_2c55930e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselMultipleSlidesPerView.vue?vue&type=template&id=2c55930e& */ "./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=template&id=2c55930e&");
/* harmony import */ var _CarouselMultipleSlidesPerView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselMultipleSlidesPerView.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CarouselMultipleSlidesPerView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselMultipleSlidesPerView_vue_vue_type_template_id_2c55930e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselMultipleSlidesPerView_vue_vue_type_template_id_2c55930e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselMultipleSlidesPerView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselMultipleSlidesPerView.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselMultipleSlidesPerView_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=template&id=2c55930e&":
/*!**************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=template&id=2c55930e& ***!
  \**************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselMultipleSlidesPerView_vue_vue_type_template_id_2c55930e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselMultipleSlidesPerView.vue?vue&type=template&id=2c55930e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselMultipleSlidesPerView.vue?vue&type=template&id=2c55930e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselMultipleSlidesPerView_vue_vue_type_template_id_2c55930e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselMultipleSlidesPerView_vue_vue_type_template_id_2c55930e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselNavigation_vue_vue_type_template_id_06363be6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselNavigation.vue?vue&type=template&id=06363be6& */ "./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=template&id=06363be6&");
/* harmony import */ var _CarouselNavigation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselNavigation.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CarouselNavigation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselNavigation_vue_vue_type_template_id_06363be6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselNavigation_vue_vue_type_template_id_06363be6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselNavigation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselNavigation.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselNavigation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=template&id=06363be6&":
/*!***************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=template&id=06363be6& ***!
  \***************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselNavigation_vue_vue_type_template_id_06363be6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselNavigation.vue?vue&type=template&id=06363be6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselNavigation.vue?vue&type=template&id=06363be6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselNavigation_vue_vue_type_template_id_06363be6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselNavigation_vue_vue_type_template_id_06363be6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselPagination_vue_vue_type_template_id_048b366c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselPagination.vue?vue&type=template&id=048b366c& */ "./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=template&id=048b366c&");
/* harmony import */ var _CarouselPagination_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselPagination.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CarouselPagination_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselPagination_vue_vue_type_template_id_048b366c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselPagination_vue_vue_type_template_id_048b366c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselPagination_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselPagination.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselPagination_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=template&id=048b366c&":
/*!***************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=template&id=048b366c& ***!
  \***************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselPagination_vue_vue_type_template_id_048b366c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselPagination.vue?vue&type=template&id=048b366c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselPagination.vue?vue&type=template&id=048b366c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselPagination_vue_vue_type_template_id_048b366c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselPagination_vue_vue_type_template_id_048b366c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselParallax_vue_vue_type_template_id_15c8272e_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselParallax.vue?vue&type=template&id=15c8272e&scoped=true& */ "./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=template&id=15c8272e&scoped=true&");
/* harmony import */ var _CarouselParallax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselParallax.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _CarouselParallax_vue_vue_type_style_index_0_id_15c8272e_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css& */ "./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _CarouselParallax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselParallax_vue_vue_type_template_id_15c8272e_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselParallax_vue_vue_type_template_id_15c8272e_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "15c8272e",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselParallax.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css&":
/*!***************************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css& ***!
  \***************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_style_index_0_id_15c8272e_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader??ref--7-1!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=style&index=0&id=15c8272e&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_style_index_0_id_15c8272e_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_style_index_0_id_15c8272e_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_style_index_0_id_15c8272e_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_style_index_0_id_15c8272e_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_7_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_style_index_0_id_15c8272e_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=template&id=15c8272e&scoped=true&":
/*!*************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=template&id=15c8272e&scoped=true& ***!
  \*************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_template_id_15c8272e_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselParallax.vue?vue&type=template&id=15c8272e&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselParallax.vue?vue&type=template&id=15c8272e&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_template_id_15c8272e_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselParallax_vue_vue_type_template_id_15c8272e_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselProgress_vue_vue_type_template_id_df137402___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselProgress.vue?vue&type=template&id=df137402& */ "./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=template&id=df137402&");
/* harmony import */ var _CarouselProgress_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselProgress.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CarouselProgress_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselProgress_vue_vue_type_template_id_df137402___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselProgress_vue_vue_type_template_id_df137402___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselProgress_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselProgress.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselProgress_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=template&id=df137402&":
/*!*************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=template&id=df137402& ***!
  \*************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselProgress_vue_vue_type_template_id_df137402___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselProgress.vue?vue&type=template&id=df137402& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselProgress.vue?vue&type=template&id=df137402&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselProgress_vue_vue_type_template_id_df137402___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselProgress_vue_vue_type_template_id_df137402___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselResponsiveBreakpoints_vue_vue_type_template_id_66366e6c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselResponsiveBreakpoints.vue?vue&type=template&id=66366e6c& */ "./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=template&id=66366e6c&");
/* harmony import */ var _CarouselResponsiveBreakpoints_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselResponsiveBreakpoints.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CarouselResponsiveBreakpoints_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselResponsiveBreakpoints_vue_vue_type_template_id_66366e6c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselResponsiveBreakpoints_vue_vue_type_template_id_66366e6c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselResponsiveBreakpoints_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselResponsiveBreakpoints.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselResponsiveBreakpoints_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=template&id=66366e6c&":
/*!**************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=template&id=66366e6c& ***!
  \**************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselResponsiveBreakpoints_vue_vue_type_template_id_66366e6c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselResponsiveBreakpoints.vue?vue&type=template&id=66366e6c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselResponsiveBreakpoints.vue?vue&type=template&id=66366e6c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselResponsiveBreakpoints_vue_vue_type_template_id_66366e6c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselResponsiveBreakpoints_vue_vue_type_template_id_66366e6c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CarouselVirtualSlides_vue_vue_type_template_id_6d18e86b_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CarouselVirtualSlides.vue?vue&type=template&id=6d18e86b&scoped=true& */ "./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=template&id=6d18e86b&scoped=true&");
/* harmony import */ var _CarouselVirtualSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CarouselVirtualSlides.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _CarouselVirtualSlides_vue_vue_type_style_index_0_id_6d18e86b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true& */ "./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _CarouselVirtualSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CarouselVirtualSlides_vue_vue_type_template_id_6d18e86b_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CarouselVirtualSlides_vue_vue_type_template_id_6d18e86b_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "6d18e86b",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselVirtualSlides.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true&":
/*!*********************************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true& ***!
  \*********************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_style_index_0_id_6d18e86b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=style&index=0&id=6d18e86b&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_style_index_0_id_6d18e86b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_style_index_0_id_6d18e86b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_style_index_0_id_6d18e86b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_style_index_0_id_6d18e86b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_style_index_0_id_6d18e86b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=template&id=6d18e86b&scoped=true&":
/*!******************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=template&id=6d18e86b&scoped=true& ***!
  \******************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_template_id_6d18e86b_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./CarouselVirtualSlides.vue?vue&type=template&id=6d18e86b&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/extra-components/carousel/CarouselVirtualSlides.vue?vue&type=template&id=6d18e86b&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_template_id_6d18e86b_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_CarouselVirtualSlides_vue_vue_type_template_id_6d18e86b_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);